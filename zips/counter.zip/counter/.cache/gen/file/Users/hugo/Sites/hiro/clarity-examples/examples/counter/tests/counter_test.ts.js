import { Clarinet, Tx, types } from "https://deno.land/x/clarinet@v1.5.2/index.ts";
Clarinet.test({
    name: "get-count returns u0 for principals that never called count-up before",
    fn (chain, accounts) {
        // Get the wallet_1 account from settings/devnet.toml
        const wallet1 = accounts.get("wallet_1");
        // Call the get-count read-only function.
        // the first parameter is the contract name
        // the second the function name
        // the third the function arguments as an array of clarity values
        // the final parameter is the tx-sender address
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a uint with a value of 0 (u0).
        count.result.expectUint(0);
    }
});
Clarinet.test({
    name: "count-up counts up for the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        // Mine a block with one transaction.
        const block = chain.mineBlock([
            // Generate a contract call to count-up from the deployer address.
            Tx.contractCall("counter", "count-up", [], wallet1.address), 
        ]);
        // Get the first (and only) transaction receipt.
        const receipt = block.receipts[0];
        // Assert that the returned result is a boolean true.
        receipt.result.expectOk().expectBool(true);
        // Get the counter value.
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a u1.
        count.result.expectUint(1);
    }
});
Clarinet.test({
    name: "counters are specific to the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        const wallet2 = accounts.get("wallet_2");
        chain.mineBlock([
            // Wallet 1 calls count-up one time.
            Tx.contractCall("counter", "count-up", [], wallet1.address),
            // Wallet 2 calls count-up two times.
            Tx.contractCall("counter", "count-up", [], wallet2.address),
            Tx.contractCall("counter", "count-up", [], wallet2.address), 
        ]);
        // Get and assert the counter value for wallet 1.
        const wallet1Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        wallet1Count.result.expectUint(1);
        // Get and assert the counter value for wallet 2.
        const wallet2Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet2.address)
        ], wallet2.address);
        wallet2Count.result.expectUint(2);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vVXNlcnMvaHVnby9TaXRlcy9oaXJvL2NsYXJpdHktZXhhbXBsZXMvZXhhbXBsZXMvY291bnRlci90ZXN0cy9jb3VudGVyX3Rlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xhcmluZXQsIFR4LCBDaGFpbiwgQWNjb3VudCwgdHlwZXMgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9jbGFyaW5ldEB2MS41LjIvaW5kZXgudHNcIjtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiZ2V0LWNvdW50IHJldHVybnMgdTAgZm9yIHByaW5jaXBhbHMgdGhhdCBuZXZlciBjYWxsZWQgY291bnQtdXAgYmVmb3JlXCIsXG4gIGZuKGNoYWluOiBDaGFpbiwgYWNjb3VudHM6IE1hcDxzdHJpbmcsIEFjY291bnQ+KSB7XG4gICAgLy8gR2V0IHRoZSB3YWxsZXRfMSBhY2NvdW50IGZyb20gc2V0dGluZ3MvZGV2bmV0LnRvbWxcbiAgICBjb25zdCB3YWxsZXQxID0gYWNjb3VudHMuZ2V0KFwid2FsbGV0XzFcIikhO1xuXG4gICAgLy8gQ2FsbCB0aGUgZ2V0LWNvdW50IHJlYWQtb25seSBmdW5jdGlvbi5cbiAgICAvLyB0aGUgZmlyc3QgcGFyYW1ldGVyIGlzIHRoZSBjb250cmFjdCBuYW1lXG4gICAgLy8gdGhlIHNlY29uZCB0aGUgZnVuY3Rpb24gbmFtZVxuICAgIC8vIHRoZSB0aGlyZCB0aGUgZnVuY3Rpb24gYXJndW1lbnRzIGFzIGFuIGFycmF5IG9mIGNsYXJpdHkgdmFsdWVzXG4gICAgLy8gdGhlIGZpbmFsIHBhcmFtZXRlciBpcyB0aGUgdHgtc2VuZGVyIGFkZHJlc3NcbiAgICBjb25zdCBjb3VudCA9IGNoYWluLmNhbGxSZWFkT25seUZuKFxuICAgICAgXCJjb3VudGVyXCIsXG4gICAgICBcImdldC1jb3VudFwiLFxuICAgICAgW3R5cGVzLnByaW5jaXBhbCh3YWxsZXQxLmFkZHJlc3MpXSxcbiAgICAgIHdhbGxldDEuYWRkcmVzc1xuICAgICk7XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgdWludCB3aXRoIGEgdmFsdWUgb2YgMCAodTApLlxuICAgIGNvdW50LnJlc3VsdC5leHBlY3RVaW50KDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcImNvdW50LXVwIGNvdW50cyB1cCBmb3IgdGhlIHR4LXNlbmRlclwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IHdhbGxldDEgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMVwiKSE7XG5cbiAgICAvLyBNaW5lIGEgYmxvY2sgd2l0aCBvbmUgdHJhbnNhY3Rpb24uXG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgLy8gR2VuZXJhdGUgYSBjb250cmFjdCBjYWxsIHRvIGNvdW50LXVwIGZyb20gdGhlIGRlcGxveWVyIGFkZHJlc3MuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDEuYWRkcmVzcyksXG4gICAgXSk7XG5cbiAgICAvLyBHZXQgdGhlIGZpcnN0IChhbmQgb25seSkgdHJhbnNhY3Rpb24gcmVjZWlwdC5cbiAgICBjb25zdCByZWNlaXB0ID0gYmxvY2sucmVjZWlwdHNbMF07XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgYm9vbGVhbiB0cnVlLlxuICAgIHJlY2VpcHQucmVzdWx0LmV4cGVjdE9rKCkuZXhwZWN0Qm9vbCh0cnVlKTtcblxuICAgIC8vIEdldCB0aGUgY291bnRlciB2YWx1ZS5cbiAgICBjb25zdCBjb3VudCA9IGNoYWluLmNhbGxSZWFkT25seUZuKFxuICAgICAgXCJjb3VudGVyXCIsXG4gICAgICBcImdldC1jb3VudFwiLFxuICAgICAgW3R5cGVzLnByaW5jaXBhbCh3YWxsZXQxLmFkZHJlc3MpXSxcbiAgICAgIHdhbGxldDEuYWRkcmVzc1xuICAgICk7XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgdTEuXG4gICAgY291bnQucmVzdWx0LmV4cGVjdFVpbnQoMSk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiY291bnRlcnMgYXJlIHNwZWNpZmljIHRvIHRoZSB0eC1zZW5kZXJcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCB3YWxsZXQxID0gYWNjb3VudHMuZ2V0KFwid2FsbGV0XzFcIikhO1xuICAgIGNvbnN0IHdhbGxldDIgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMlwiKSE7XG5cbiAgICBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgLy8gV2FsbGV0IDEgY2FsbHMgY291bnQtdXAgb25lIHRpbWUuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDEuYWRkcmVzcyksXG4gICAgICAvLyBXYWxsZXQgMiBjYWxscyBjb3VudC11cCB0d28gdGltZXMuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDIuYWRkcmVzcyksXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDIuYWRkcmVzcyksXG4gICAgXSk7XG5cbiAgICAvLyBHZXQgYW5kIGFzc2VydCB0aGUgY291bnRlciB2YWx1ZSBmb3Igd2FsbGV0IDEuXG4gICAgY29uc3Qgd2FsbGV0MUNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDEuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0MS5hZGRyZXNzXG4gICAgKTtcbiAgICB3YWxsZXQxQ291bnQucmVzdWx0LmV4cGVjdFVpbnQoMSk7XG5cbiAgICAvLyBHZXQgYW5kIGFzc2VydCB0aGUgY291bnRlciB2YWx1ZSBmb3Igd2FsbGV0IDIuXG4gICAgY29uc3Qgd2FsbGV0MkNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDIuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0Mi5hZGRyZXNzXG4gICAgKTtcbiAgICB3YWxsZXQyQ291bnQucmVzdWx0LmV4cGVjdFVpbnQoMik7XG4gIH0sXG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFFBQVEsRUFBRSxFQUFFLEVBQWtCLEtBQUssUUFBUSw4Q0FBOEMsQ0FBQztBQUVuRyxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLHVFQUF1RTtJQUM3RSxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MscURBQXFEO1FBQ3JELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEFBQUMsQUFBQztRQUUxQyx5Q0FBeUM7UUFDekMsMkNBQTJDO1FBQzNDLCtCQUErQjtRQUMvQixpRUFBaUU7UUFDakUsK0NBQStDO1FBQy9DLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQ2hDLFNBQVMsRUFDVCxXQUFXLEVBQ1g7WUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FBQyxFQUNsQyxPQUFPLENBQUMsT0FBTyxDQUNoQixBQUFDO1FBRUYsb0VBQW9FO1FBQ3BFLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQzVCO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSxzQ0FBc0M7SUFDNUMsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEFBQUMsQUFBQztRQUUxQyxxQ0FBcUM7UUFDckMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixrRUFBa0U7WUFDbEUsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQzVELENBQUMsQUFBQztRQUVILGdEQUFnRDtRQUNoRCxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxBQUFDO1FBRWxDLHFEQUFxRDtRQUNyRCxPQUFPLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUUzQyx5QkFBeUI7UUFDekIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FDaEMsU0FBUyxFQUNULFdBQVcsRUFDWDtZQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUFDLEVBQ2xDLE9BQU8sQ0FBQyxPQUFPLENBQ2hCLEFBQUM7UUFFRiwyQ0FBMkM7UUFDM0MsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDNUI7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLHdDQUF3QztJQUM5QyxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQUFBQyxBQUFDO1FBQzFDLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEFBQUMsQUFBQztRQUUxQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ2Qsb0NBQW9DO1lBQ3BDLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUMzRCxxQ0FBcUM7WUFDckMsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQzNELEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUM1RCxDQUFDLENBQUM7UUFFSCxpREFBaUQ7UUFDakQsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FDdkMsU0FBUyxFQUNULFdBQVcsRUFDWDtZQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUFDLEVBQ2xDLE9BQU8sQ0FBQyxPQUFPLENBQ2hCLEFBQUM7UUFDRixZQUFZLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsQyxpREFBaUQ7UUFDakQsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FDdkMsU0FBUyxFQUNULFdBQVcsRUFDWDtZQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUFDLEVBQ2xDLE9BQU8sQ0FBQyxPQUFPLENBQ2hCLEFBQUM7UUFDRixZQUFZLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNuQztDQUNGLENBQUMsQ0FBQyJ9