import { Clarinet, Tx, types } from "https://deno.land/x/clarinet@v1.5.2/index.ts";
Clarinet.test({
    name: "get-count returns u0 for principals that never called count-up before",
    fn (chain, accounts) {
        // Get the wallet_1 account from settings/devnet.toml
        const wallet1 = accounts.get("wallet_1");
        // Call the get-count read-only function.
        // the first parameter is the contract name
        // the second the function name
        // the third the function arguments as an array of clarity values
        // the final parameter is the tx-sender address
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a uint with a value of 0 (u0).
        count.result.expectUint(0);
    }
});
Clarinet.test({
    name: "count-up counts up for the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        // Mine a block with one transaction.
        const block = chain.mineBlock([
            // Generate a contract call to count-up from the deployer address.
            Tx.contractCall("counter", "count-up", [], wallet1.address), 
        ]);
        // Get the first (and only) transaction receipt.
        const receipt = block.receipts[0];
        // Assert that the returned result is a boolean true.
        receipt.result.expectOk().expectBool(true);
        // Get the counter value.
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a u1.
        count.result.expectUint(1);
    }
});
Clarinet.test({
    name: "counters are specific to the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        const wallet2 = accounts.get("wallet_2");
        chain.mineBlock([
            // Wallet 1 calls count-up one time.
            Tx.contractCall("counter", "count-up", [], wallet1.address),
            // Wallet 2 calls count-up two times.
            Tx.contractCall("counter", "count-up", [], wallet2.address),
            Tx.contractCall("counter", "count-up", [], wallet2.address), 
        ]);
        // Get and assert the counter value for wallet 1.
        const wallet1Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        wallet1Count.result.expectUint(1);
        // Get and assert the counter value for wallet 2.
        const wallet2Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet2.address)
        ], wallet2.address);
        wallet2Count.result.expectUint(2);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vVXNlcnMvaHVnby9TaXRlcy9oaXJvL2NsYXJpdHktZXhhbXBsZXMvZXhhbXBsZXMvY291bnRlci90ZXN0cy9jb3VudGVyX3Rlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ2xhcmluZXQsXG4gIFR4LFxuICBDaGFpbixcbiAgQWNjb3VudCxcbiAgdHlwZXMsXG59IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L2NsYXJpbmV0QHYxLjUuMi9pbmRleC50c1wiO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJnZXQtY291bnQgcmV0dXJucyB1MCBmb3IgcHJpbmNpcGFscyB0aGF0IG5ldmVyIGNhbGxlZCBjb3VudC11cCBiZWZvcmVcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICAvLyBHZXQgdGhlIHdhbGxldF8xIGFjY291bnQgZnJvbSBzZXR0aW5ncy9kZXZuZXQudG9tbFxuICAgIGNvbnN0IHdhbGxldDEgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMVwiKSE7XG5cbiAgICAvLyBDYWxsIHRoZSBnZXQtY291bnQgcmVhZC1vbmx5IGZ1bmN0aW9uLlxuICAgIC8vIHRoZSBmaXJzdCBwYXJhbWV0ZXIgaXMgdGhlIGNvbnRyYWN0IG5hbWVcbiAgICAvLyB0aGUgc2Vjb25kIHRoZSBmdW5jdGlvbiBuYW1lXG4gICAgLy8gdGhlIHRoaXJkIHRoZSBmdW5jdGlvbiBhcmd1bWVudHMgYXMgYW4gYXJyYXkgb2YgY2xhcml0eSB2YWx1ZXNcbiAgICAvLyB0aGUgZmluYWwgcGFyYW1ldGVyIGlzIHRoZSB0eC1zZW5kZXIgYWRkcmVzc1xuICAgIGNvbnN0IGNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDEuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0MS5hZGRyZXNzXG4gICAgKTtcblxuICAgIC8vIEFzc2VydCB0aGF0IHRoZSByZXR1cm5lZCByZXN1bHQgaXMgYSB1aW50IHdpdGggYSB2YWx1ZSBvZiAwICh1MCkuXG4gICAgY291bnQucmVzdWx0LmV4cGVjdFVpbnQoMCk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiY291bnQtdXAgY291bnRzIHVwIGZvciB0aGUgdHgtc2VuZGVyXCIsXG4gIGZuKGNoYWluOiBDaGFpbiwgYWNjb3VudHM6IE1hcDxzdHJpbmcsIEFjY291bnQ+KSB7XG4gICAgY29uc3Qgd2FsbGV0MSA9IGFjY291bnRzLmdldChcIndhbGxldF8xXCIpITtcblxuICAgIC8vIE1pbmUgYSBibG9jayB3aXRoIG9uZSB0cmFuc2FjdGlvbi5cbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICAvLyBHZW5lcmF0ZSBhIGNvbnRyYWN0IGNhbGwgdG8gY291bnQtdXAgZnJvbSB0aGUgZGVwbG95ZXIgYWRkcmVzcy5cbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcImNvdW50ZXJcIiwgXCJjb3VudC11cFwiLCBbXSwgd2FsbGV0MS5hZGRyZXNzKSxcbiAgICBdKTtcblxuICAgIC8vIEdldCB0aGUgZmlyc3QgKGFuZCBvbmx5KSB0cmFuc2FjdGlvbiByZWNlaXB0LlxuICAgIGNvbnN0IHJlY2VpcHQgPSBibG9jay5yZWNlaXB0c1swXTtcblxuICAgIC8vIEFzc2VydCB0aGF0IHRoZSByZXR1cm5lZCByZXN1bHQgaXMgYSBib29sZWFuIHRydWUuXG4gICAgcmVjZWlwdC5yZXN1bHQuZXhwZWN0T2soKS5leHBlY3RCb29sKHRydWUpO1xuXG4gICAgLy8gR2V0IHRoZSBjb3VudGVyIHZhbHVlLlxuICAgIGNvbnN0IGNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDEuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0MS5hZGRyZXNzXG4gICAgKTtcblxuICAgIC8vIEFzc2VydCB0aGF0IHRoZSByZXR1cm5lZCByZXN1bHQgaXMgYSB1MS5cbiAgICBjb3VudC5yZXN1bHQuZXhwZWN0VWludCgxKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJjb3VudGVycyBhcmUgc3BlY2lmaWMgdG8gdGhlIHR4LXNlbmRlclwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IHdhbGxldDEgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMVwiKSE7XG4gICAgY29uc3Qgd2FsbGV0MiA9IGFjY291bnRzLmdldChcIndhbGxldF8yXCIpITtcblxuICAgIGNoYWluLm1pbmVCbG9jayhbXG4gICAgICAvLyBXYWxsZXQgMSBjYWxscyBjb3VudC11cCBvbmUgdGltZS5cbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcImNvdW50ZXJcIiwgXCJjb3VudC11cFwiLCBbXSwgd2FsbGV0MS5hZGRyZXNzKSxcbiAgICAgIC8vIFdhbGxldCAyIGNhbGxzIGNvdW50LXVwIHR3byB0aW1lcy5cbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcImNvdW50ZXJcIiwgXCJjb3VudC11cFwiLCBbXSwgd2FsbGV0Mi5hZGRyZXNzKSxcbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcImNvdW50ZXJcIiwgXCJjb3VudC11cFwiLCBbXSwgd2FsbGV0Mi5hZGRyZXNzKSxcbiAgICBdKTtcblxuICAgIC8vIEdldCBhbmQgYXNzZXJ0IHRoZSBjb3VudGVyIHZhbHVlIGZvciB3YWxsZXQgMS5cbiAgICBjb25zdCB3YWxsZXQxQ291bnQgPSBjaGFpbi5jYWxsUmVhZE9ubHlGbihcbiAgICAgIFwiY291bnRlclwiLFxuICAgICAgXCJnZXQtY291bnRcIixcbiAgICAgIFt0eXBlcy5wcmluY2lwYWwod2FsbGV0MS5hZGRyZXNzKV0sXG4gICAgICB3YWxsZXQxLmFkZHJlc3NcbiAgICApO1xuICAgIHdhbGxldDFDb3VudC5yZXN1bHQuZXhwZWN0VWludCgxKTtcblxuICAgIC8vIEdldCBhbmQgYXNzZXJ0IHRoZSBjb3VudGVyIHZhbHVlIGZvciB3YWxsZXQgMi5cbiAgICBjb25zdCB3YWxsZXQyQ291bnQgPSBjaGFpbi5jYWxsUmVhZE9ubHlGbihcbiAgICAgIFwiY291bnRlclwiLFxuICAgICAgXCJnZXQtY291bnRcIixcbiAgICAgIFt0eXBlcy5wcmluY2lwYWwod2FsbGV0Mi5hZGRyZXNzKV0sXG4gICAgICB3YWxsZXQyLmFkZHJlc3NcbiAgICApO1xuICAgIHdhbGxldDJDb3VudC5yZXN1bHQuZXhwZWN0VWludCgyKTtcbiAgfSxcbn0pO1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQ0UsUUFBUSxFQUNSLEVBQUUsRUFHRixLQUFLLFFBQ0EsOENBQThDLENBQUM7QUFFdEQsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSx1RUFBdUU7SUFDN0UsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLHFEQUFxRDtRQUNyRCxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxBQUFDLEFBQUM7UUFFMUMseUNBQXlDO1FBQ3pDLDJDQUEyQztRQUMzQywrQkFBK0I7UUFDL0IsaUVBQWlFO1FBQ2pFLCtDQUErQztRQUMvQyxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsY0FBYyxDQUNoQyxTQUFTLEVBQ1QsV0FBVyxFQUNYO1lBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQUMsRUFDbEMsT0FBTyxDQUFDLE9BQU8sQ0FDaEIsQUFBQztRQUVGLG9FQUFvRTtRQUNwRSxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUM1QjtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsc0NBQXNDO0lBQzVDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxBQUFDLEFBQUM7UUFFMUMscUNBQXFDO1FBQ3JDLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsa0VBQWtFO1lBQ2xFLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUM1RCxDQUFDLEFBQUM7UUFFSCxnREFBZ0Q7UUFDaEQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQUFBQztRQUVsQyxxREFBcUQ7UUFDckQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFM0MseUJBQXlCO1FBQ3pCLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQ2hDLFNBQVMsRUFDVCxXQUFXLEVBQ1g7WUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FBQyxFQUNsQyxPQUFPLENBQUMsT0FBTyxDQUNoQixBQUFDO1FBRUYsMkNBQTJDO1FBQzNDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQzVCO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSx3Q0FBd0M7SUFDOUMsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEFBQUMsQUFBQztRQUMxQyxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxBQUFDLEFBQUM7UUFFMUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUNkLG9DQUFvQztZQUNwQyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDM0QscUNBQXFDO1lBQ3JDLEVBQUUsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUMzRCxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FDNUQsQ0FBQyxDQUFDO1FBRUgsaURBQWlEO1FBQ2pELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQ3ZDLFNBQVMsRUFDVCxXQUFXLEVBQ1g7WUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FBQyxFQUNsQyxPQUFPLENBQUMsT0FBTyxDQUNoQixBQUFDO1FBQ0YsWUFBWSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbEMsaURBQWlEO1FBQ2pELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQ3ZDLFNBQVMsRUFDVCxXQUFXLEVBQ1g7WUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FBQyxFQUNsQyxPQUFPLENBQUMsT0FBTyxDQUNoQixBQUFDO1FBQ0YsWUFBWSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDbkM7Q0FDRixDQUFDLENBQUMifQ==