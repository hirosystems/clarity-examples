import { Clarinet, Tx, types } from "https://deno.land/x/clarinet@v1.5.2/index.ts";
Clarinet.test({
    name: "get-count returns u0 for principals that never called count-up before",
    fn (chain, accounts) {
        // Get on of the accounts from devnet.toml
        const wallet1 = accounts.get("wallet_1");
        // Call the get-count read-only function.
        // the first parameter is the contract name
        // the second the function name
        // the third the function arguments as an array of clarity values
        // the final parameter is the tx-sender address
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a uint with a value of 0 (u0).
        count.result.expectUint(0);
    }
});
Clarinet.test({
    name: "count-up counts up for the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        // Mine a block with one transaction.
        const block = chain.mineBlock([
            // Generate a contract call to count-up from the deployer address.
            Tx.contractCall("counter", "count-up", [], wallet1.address), 
        ]);
        // Get the first (and only) transaction receipt.
        const receipt = block.receipts[0];
        // Assert that the returned result is a boolean true.
        receipt.result.expectOk().expectBool(true);
        // Get the counter value.
        const count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        // Assert that the returned result is a u1.
        count.result.expectUint(1);
    }
});
Clarinet.test({
    name: "counters are specific to the tx-sender",
    fn (chain, accounts) {
        const wallet1 = accounts.get("wallet_1");
        const wallet2 = accounts.get("wallet_2");
        chain.mineBlock([
            // Wallet 1 calls count-up one time.
            Tx.contractCall("counter", "count-up", [], wallet1.address),
            // Wallet 2 calls count-up two times.
            Tx.contractCall("counter", "count-up", [], wallet2.address),
            Tx.contractCall("counter", "count-up", [], wallet2.address), 
        ]);
        // Get and assert the counter value for wallet 1.
        const wallet1Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet1.address)
        ], wallet1.address);
        wallet1Count.result.expectUint(1);
        // Get and assert the counter value for wallet 2.
        const wallet2Count = chain.callReadOnlyFn("counter", "get-count", [
            types.principal(wallet2.address)
        ], wallet2.address);
        wallet2Count.result.expectUint(2);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vVXNlcnMvaHVnby9TaXRlcy9oaXJvL2NsYXJpdHktZXhhbXBsZXMvZXhhbXBsZXMvY291bnRlci90ZXN0cy9jb3VudGVyX3Rlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ2xhcmluZXQsXG4gIFR4LFxuICBDaGFpbixcbiAgQWNjb3VudCxcbiAgdHlwZXMsXG59IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L2NsYXJpbmV0QHYxLjUuMi9pbmRleC50c1wiO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJnZXQtY291bnQgcmV0dXJucyB1MCBmb3IgcHJpbmNpcGFscyB0aGF0IG5ldmVyIGNhbGxlZCBjb3VudC11cCBiZWZvcmVcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICAvLyBHZXQgb24gb2YgdGhlIGFjY291bnRzIGZyb20gZGV2bmV0LnRvbWxcbiAgICBjb25zdCB3YWxsZXQxID0gYWNjb3VudHMuZ2V0KFwid2FsbGV0XzFcIikhO1xuXG4gICAgLy8gQ2FsbCB0aGUgZ2V0LWNvdW50IHJlYWQtb25seSBmdW5jdGlvbi5cbiAgICAvLyB0aGUgZmlyc3QgcGFyYW1ldGVyIGlzIHRoZSBjb250cmFjdCBuYW1lXG4gICAgLy8gdGhlIHNlY29uZCB0aGUgZnVuY3Rpb24gbmFtZVxuICAgIC8vIHRoZSB0aGlyZCB0aGUgZnVuY3Rpb24gYXJndW1lbnRzIGFzIGFuIGFycmF5IG9mIGNsYXJpdHkgdmFsdWVzXG4gICAgLy8gdGhlIGZpbmFsIHBhcmFtZXRlciBpcyB0aGUgdHgtc2VuZGVyIGFkZHJlc3NcbiAgICBjb25zdCBjb3VudCA9IGNoYWluLmNhbGxSZWFkT25seUZuKFxuICAgICAgXCJjb3VudGVyXCIsXG4gICAgICBcImdldC1jb3VudFwiLFxuICAgICAgW3R5cGVzLnByaW5jaXBhbCh3YWxsZXQxLmFkZHJlc3MpXSxcbiAgICAgIHdhbGxldDEuYWRkcmVzc1xuICAgICk7XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgdWludCB3aXRoIGEgdmFsdWUgb2YgMCAodTApLlxuICAgIGNvdW50LnJlc3VsdC5leHBlY3RVaW50KDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcImNvdW50LXVwIGNvdW50cyB1cCBmb3IgdGhlIHR4LXNlbmRlclwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IHdhbGxldDEgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMVwiKSE7XG5cbiAgICAvLyBNaW5lIGEgYmxvY2sgd2l0aCBvbmUgdHJhbnNhY3Rpb24uXG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgLy8gR2VuZXJhdGUgYSBjb250cmFjdCBjYWxsIHRvIGNvdW50LXVwIGZyb20gdGhlIGRlcGxveWVyIGFkZHJlc3MuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDEuYWRkcmVzcyksXG4gICAgXSk7XG5cbiAgICAvLyBHZXQgdGhlIGZpcnN0IChhbmQgb25seSkgdHJhbnNhY3Rpb24gcmVjZWlwdC5cbiAgICBjb25zdCByZWNlaXB0ID0gYmxvY2sucmVjZWlwdHNbMF07XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgYm9vbGVhbiB0cnVlLlxuICAgIHJlY2VpcHQucmVzdWx0LmV4cGVjdE9rKCkuZXhwZWN0Qm9vbCh0cnVlKTtcblxuICAgIC8vIEdldCB0aGUgY291bnRlciB2YWx1ZS5cbiAgICBjb25zdCBjb3VudCA9IGNoYWluLmNhbGxSZWFkT25seUZuKFxuICAgICAgXCJjb3VudGVyXCIsXG4gICAgICBcImdldC1jb3VudFwiLFxuICAgICAgW3R5cGVzLnByaW5jaXBhbCh3YWxsZXQxLmFkZHJlc3MpXSxcbiAgICAgIHdhbGxldDEuYWRkcmVzc1xuICAgICk7XG5cbiAgICAvLyBBc3NlcnQgdGhhdCB0aGUgcmV0dXJuZWQgcmVzdWx0IGlzIGEgdTEuXG4gICAgY291bnQucmVzdWx0LmV4cGVjdFVpbnQoMSk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiY291bnRlcnMgYXJlIHNwZWNpZmljIHRvIHRoZSB0eC1zZW5kZXJcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCB3YWxsZXQxID0gYWNjb3VudHMuZ2V0KFwid2FsbGV0XzFcIikhO1xuICAgIGNvbnN0IHdhbGxldDIgPSBhY2NvdW50cy5nZXQoXCJ3YWxsZXRfMlwiKSE7XG5cbiAgICBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgLy8gV2FsbGV0IDEgY2FsbHMgY291bnQtdXAgb25lIHRpbWUuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDEuYWRkcmVzcyksXG4gICAgICAvLyBXYWxsZXQgMiBjYWxscyBjb3VudC11cCB0d28gdGltZXMuXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDIuYWRkcmVzcyksXG4gICAgICBUeC5jb250cmFjdENhbGwoXCJjb3VudGVyXCIsIFwiY291bnQtdXBcIiwgW10sIHdhbGxldDIuYWRkcmVzcyksXG4gICAgXSk7XG5cbiAgICAvLyBHZXQgYW5kIGFzc2VydCB0aGUgY291bnRlciB2YWx1ZSBmb3Igd2FsbGV0IDEuXG4gICAgY29uc3Qgd2FsbGV0MUNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDEuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0MS5hZGRyZXNzXG4gICAgKTtcbiAgICB3YWxsZXQxQ291bnQucmVzdWx0LmV4cGVjdFVpbnQoMSk7XG5cbiAgICAvLyBHZXQgYW5kIGFzc2VydCB0aGUgY291bnRlciB2YWx1ZSBmb3Igd2FsbGV0IDIuXG4gICAgY29uc3Qgd2FsbGV0MkNvdW50ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBcImNvdW50ZXJcIixcbiAgICAgIFwiZ2V0LWNvdW50XCIsXG4gICAgICBbdHlwZXMucHJpbmNpcGFsKHdhbGxldDIuYWRkcmVzcyldLFxuICAgICAgd2FsbGV0Mi5hZGRyZXNzXG4gICAgKTtcbiAgICB3YWxsZXQyQ291bnQucmVzdWx0LmV4cGVjdFVpbnQoMik7XG4gIH0sXG59KTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxTQUNFLFFBQVEsRUFDUixFQUFFLEVBR0YsS0FBSyxRQUNBLDhDQUE4QyxDQUFDO0FBRXRELFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsdUVBQXVFO0lBQzdFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQywwQ0FBMEM7UUFDMUMsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQUFBQyxBQUFDO1FBRTFDLHlDQUF5QztRQUN6QywyQ0FBMkM7UUFDM0MsK0JBQStCO1FBQy9CLGlFQUFpRTtRQUNqRSwrQ0FBK0M7UUFDL0MsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FDaEMsU0FBUyxFQUNULFdBQVcsRUFDWDtZQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUFDLEVBQ2xDLE9BQU8sQ0FBQyxPQUFPLENBQ2hCLEFBQUM7UUFFRixvRUFBb0U7UUFDcEUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDNUI7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLHNDQUFzQztJQUM1QyxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQUFBQyxBQUFDO1FBRTFDLHFDQUFxQztRQUNyQyxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGtFQUFrRTtZQUNsRSxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FDNUQsQ0FBQyxBQUFDO1FBRUgsZ0RBQWdEO1FBQ2hELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEFBQUM7UUFFbEMscURBQXFEO1FBQ3JELE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTNDLHlCQUF5QjtRQUN6QixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsY0FBYyxDQUNoQyxTQUFTLEVBQ1QsV0FBVyxFQUNYO1lBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQUMsRUFDbEMsT0FBTyxDQUFDLE9BQU8sQ0FDaEIsQUFBQztRQUVGLDJDQUEyQztRQUMzQyxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUM1QjtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsd0NBQXdDO0lBQzlDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxBQUFDLEFBQUM7UUFDMUMsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQUFBQyxBQUFDO1FBRTFDLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDZCxvQ0FBb0M7WUFDcEMsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQzNELHFDQUFxQztZQUNyQyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDM0QsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQzVELENBQUMsQ0FBQztRQUVILGlEQUFpRDtRQUNqRCxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsY0FBYyxDQUN2QyxTQUFTLEVBQ1QsV0FBVyxFQUNYO1lBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQUMsRUFDbEMsT0FBTyxDQUFDLE9BQU8sQ0FDaEIsQUFBQztRQUNGLFlBQVksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWxDLGlEQUFpRDtRQUNqRCxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsY0FBYyxDQUN2QyxTQUFTLEVBQ1QsV0FBVyxFQUNYO1lBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQUMsRUFDbEMsT0FBTyxDQUFDLE9BQU8sQ0FDaEIsQUFBQztRQUNGLFlBQVksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ25DO0NBQ0YsQ0FBQyxDQUFDIn0=