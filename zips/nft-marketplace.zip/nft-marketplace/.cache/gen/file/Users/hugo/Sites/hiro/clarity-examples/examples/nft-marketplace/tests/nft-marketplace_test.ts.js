import { Clarinet, Tx, types } from "https://deno.land/x/clarinet@v1.5.2/index.ts";
import { assertEquals } from "https://deno.land/std@0.180.0/testing/asserts.ts";
const contractName = "tiny-market";
const defaultNftAssetContract = "SP2PABAF9FTAJYNFZH93XENAJ8FVY99RRM50D2JG9.nft-trait";
const defaultPaymentAssetContract = "sip010-token";
const contractPrincipal = (deployer)=>`${deployer.address}.${contractName}`;
function mintNft({ chain , deployer , recipient , nftAssetContract =defaultNftAssetContract  }) {
    const block = chain.mineBlock([
        Tx.contractCall(nftAssetContract, "mint", [
            types.principal(recipient.address)
        ], deployer.address), 
    ]);
    block.receipts[0].result.expectOk();
    const nftMintEvent = block.receipts[0].events[0].nft_mint_event;
    const [nftAssetContractPrincipal, nftAssetId] = nftMintEvent.asset_identifier.split("::");
    return {
        nftAssetContract: nftAssetContractPrincipal,
        nftAssetId,
        tokenId: nftMintEvent.value.substr(1),
        block
    };
}
function mintFt({ chain , deployer , amount , recipient , paymentAssetContract =defaultPaymentAssetContract  }) {
    const block = chain.mineBlock([
        Tx.contractCall(paymentAssetContract, "mint", [
            types.uint(amount),
            types.principal(recipient.address)
        ], deployer.address), 
    ]);
    block.receipts[0].result.expectOk();
    const ftMintEvent = block.receipts[0].events[0].ft_mint_event;
    const [paymentAssetContractPrincipal, paymentAssetId] = ftMintEvent.asset_identifier.split("::");
    return {
        paymentAssetContract: paymentAssetContractPrincipal,
        paymentAssetId,
        block
    };
}
function assertNftTransfer(event, nftAssetContract, tokenId, sender, recipient) {
    assertEquals(typeof event, "object");
    assertEquals(event.type, "nft_transfer_event");
    assertEquals(event.nft_transfer_event.asset_identifier.substr(0, nftAssetContract.length), nftAssetContract);
    event.nft_transfer_event.sender.expectPrincipal(sender);
    event.nft_transfer_event.recipient.expectPrincipal(recipient);
    event.nft_transfer_event.value.expectUint(tokenId);
}
const makeOrder = (order)=>types.tuple({
        taker: order.taker ? types.some(types.principal(order.taker)) : types.none(),
        "token-id": types.uint(order.tokenId),
        expiry: types.uint(order.expiry),
        price: types.uint(order.price),
        "payment-asset-contract": order.paymentAssetContract ? types.some(types.principal(order.paymentAssetContract)) : types.none()
    });
const whitelistAssetTx = (assetContract, whitelisted, contractOwner)=>Tx.contractCall(contractName, "set-whitelisted", [
        types.principal(assetContract),
        types.bool(whitelisted)
    ], contractOwner.address);
const listOrderTx = (nftAssetContract, maker, order)=>Tx.contractCall(contractName, "list-asset", [
        types.principal(nftAssetContract),
        typeof order === "string" ? order : makeOrder(order), 
    ], maker.address);
Clarinet.test({
    name: "Can list an NFT for sale for STX",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        block.receipts[1].result.expectOk().expectUint(0);
        assertNftTransfer(block.receipts[1].events[0], nftAssetContract, tokenId, maker.address, contractPrincipal(deployer));
    }
});
Clarinet.test({
    name: "Can list an NFT for sale for any SIP010 fungible token",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract  } = mintFt({
            chain,
            deployer,
            recipient: maker,
            amount: 1
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10,
            paymentAssetContract
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        block.receipts[2].result.expectOk().expectUint(0);
        assertNftTransfer(block.receipts[2].events[0], nftAssetContract, tokenId, maker.address, contractPrincipal(deployer));
    }
});
Clarinet.test({
    name: "Cannot list an NFT for sale if the expiry is in the past",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const expiry = 10;
        const order = {
            tokenId,
            expiry,
            price: 10
        };
        chain.mineEmptyBlockUntil(expiry + 1);
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        block.receipts[1].result.expectErr().expectUint(1000);
        assertEquals(block.receipts[1].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot list an NFT for sale for nothing",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 0
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        block.receipts[1].result.expectErr().expectUint(1001);
        assertEquals(block.receipts[1].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot list an NFT for sale that the sender does not own",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: taker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        block.receipts[1].result.expectErr().expectUint(1);
        assertEquals(block.receipts[1].events.length, 0);
    }
});
Clarinet.test({
    name: "Maker can cancel a listing",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "cancel-listing", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], maker.address), 
        ]);
        block.receipts[2].result.expectOk().expectBool(true);
        assertNftTransfer(block.receipts[2].events[0], nftAssetContract, tokenId, contractPrincipal(deployer), maker.address);
    }
});
Clarinet.test({
    name: "Non-maker cannot cancel listing",
    fn (chain, accounts) {
        const [deployer, maker, otherAccount] = [
            "deployer",
            "wallet_1",
            "wallet_2", 
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "cancel-listing", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], otherAccount.address), 
        ]);
        block.receipts[2].result.expectErr().expectUint(2001);
        assertEquals(block.receipts[2].events.length, 0);
    }
});
Clarinet.test({
    name: "Can get listings that have not been cancelled",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        const listingIdUint = block.receipts[1].result.expectOk();
        const receipt = chain.callReadOnlyFn(contractName, "get-listing", [
            listingIdUint
        ], deployer.address);
        const listing = receipt.result.expectSome().expectTuple();
        listing.expiry.expectUint(order.expiry);
        listing.maker.expectPrincipal(maker.address);
        listing.price.expectUint(order.price);
        listing.taker.expectNone();
        listing["payment-asset-contract"].expectNone();
        listing["nft-asset-contract"].expectPrincipal(nftAssetContract);
        listing["token-id"].expectUint(tokenId);
    }
});
Clarinet.test({
    name: "Cannot get listings that have been cancelled or do not exist",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        chain.mineBlock([
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "cancel-listing", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], maker.address), 
        ]);
        const receipts = [
            types.uint(0),
            types.uint(999)
        ].map((listingId)=>chain.callReadOnlyFn(contractName, "get-listing", [
                listingId
            ], deployer.address));
        receipts.map((receipt)=>receipt.result.expectNone());
    }
});
Clarinet.test({
    name: "Can fulfil an active listing with STX",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[2].result.expectOk().expectUint(0);
        assertNftTransfer(block.receipts[2].events[0], nftAssetContract, tokenId, contractPrincipal(deployer), taker.address);
        block.receipts[2].events.expectSTXTransferEvent(order.price, taker.address, maker.address);
    }
});
Clarinet.test({
    name: "Can fulfil an active listing with SIP010 fungible tokens",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const price = 50;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract , paymentAssetId  } = mintFt({
            chain,
            deployer,
            recipient: taker,
            amount: price
        });
        const order = {
            tokenId,
            expiry: 10,
            price,
            paymentAssetContract
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-ft", [
                types.uint(0),
                types.principal(nftAssetContract),
                types.principal(paymentAssetContract), 
            ], taker.address), 
        ]);
        block.receipts[3].result.expectOk().expectUint(0);
        assertNftTransfer(block.receipts[3].events[0], nftAssetContract, tokenId, contractPrincipal(deployer), taker.address);
        block.receipts[3].events.expectFungibleTokenTransferEvent(price, taker.address, maker.address, paymentAssetId);
    }
});
Clarinet.test({
    name: "Cannot fulfil own listing",
    fn (chain, accounts) {
        const [deployer, maker] = [
            "deployer",
            "wallet_1"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], maker.address), 
        ]);
        block.receipts[2].result.expectErr().expectUint(2005);
        assertEquals(block.receipts[2].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an unknown listing",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[1].result.expectErr().expectUint(2000);
        assertEquals(block.receipts[1].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an expired listing",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const expiry = 10;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry,
            price: 10
        };
        chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order), 
        ]);
        chain.mineEmptyBlockUntil(expiry + 1);
        const block = chain.mineBlock([
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[0].result.expectErr().expectUint(2002);
        assertEquals(block.receipts[0].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil a listing with a different NFT contract reference",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const expiry = 10;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10
        };
        const bogusNftAssetContract = `${deployer.address}.bogus-nft`;
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(bogusNftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[2].result.expectErr().expectUint(2003);
        assertEquals(block.receipts[2].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an active STX listing with SIP010 fungible tokens",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const price = 50;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract  } = mintFt({
            chain,
            deployer,
            recipient: taker,
            amount: price
        });
        const order = {
            tokenId,
            expiry: 10,
            price
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-ft", [
                types.uint(0),
                types.principal(nftAssetContract),
                types.principal(paymentAssetContract), 
            ], taker.address), 
        ]);
        block.receipts[3].result.expectErr().expectUint(2004);
        assertEquals(block.receipts[3].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an active SIP010 fungible token listing with STX",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const price = 50;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract  } = mintFt({
            chain,
            deployer,
            recipient: taker,
            amount: price
        });
        const order = {
            tokenId,
            expiry: 10,
            price,
            paymentAssetContract
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[3].result.expectErr().expectUint(2004);
        assertEquals(block.receipts[3].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an active SIP010 fungible token listing with a different SIP010 fungible token contract reference",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const price = 50;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract  } = mintFt({
            chain,
            deployer,
            recipient: taker,
            amount: price
        });
        const bogusPaymentAssetContract = `${deployer.address}.bogus-ft`;
        const order = {
            tokenId,
            expiry: 10,
            price,
            paymentAssetContract
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-ft", [
                types.uint(0),
                types.principal(nftAssetContract),
                types.principal(bogusPaymentAssetContract), 
            ], taker.address), 
        ]);
        block.receipts[3].result.expectErr().expectUint(2004);
        assertEquals(block.receipts[3].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an active STX listing with insufficient balance",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: taker.balance + 10
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[2].result.expectErr().expectUint(1);
        assertEquals(block.receipts[2].events.length, 0);
    }
});
Clarinet.test({
    name: "Cannot fulfil an active SIP010 fungible token listing with insufficient balance",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const price = 50;
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const { paymentAssetContract  } = mintFt({
            chain,
            deployer,
            recipient: taker,
            amount: price
        });
        const order = {
            tokenId,
            expiry: 10,
            price: taker.balance + 10,
            paymentAssetContract
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            whitelistAssetTx(paymentAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-ft", [
                types.uint(0),
                types.principal(nftAssetContract),
                types.principal(paymentAssetContract), 
            ], taker.address), 
        ]);
        block.receipts[3].result.expectErr().expectUint(1);
        assertEquals(block.receipts[3].events.length, 0);
    }
});
Clarinet.test({
    name: "Intended taker can fulfil active listing",
    fn (chain, accounts) {
        const [deployer, maker, taker] = [
            "deployer",
            "wallet_1",
            "wallet_2"
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10,
            taker: taker.address
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], taker.address), 
        ]);
        block.receipts[2].result.expectOk().expectUint(0);
        assertNftTransfer(block.receipts[2].events[0], nftAssetContract, tokenId, contractPrincipal(deployer), taker.address);
        block.receipts[2].events.expectSTXTransferEvent(order.price, taker.address, maker.address);
    }
});
Clarinet.test({
    name: "Unintended taker cannot fulfil active listing",
    fn (chain, accounts) {
        const [deployer, maker, taker, unintendedTaker] = [
            "deployer",
            "wallet_1",
            "wallet_2",
            "wallet_3", 
        ].map((name)=>accounts.get(name));
        const { nftAssetContract , tokenId  } = mintNft({
            chain,
            deployer,
            recipient: maker
        });
        const order = {
            tokenId,
            expiry: 10,
            price: 10,
            taker: taker.address
        };
        const block = chain.mineBlock([
            whitelistAssetTx(nftAssetContract, true, deployer),
            listOrderTx(nftAssetContract, maker, order),
            Tx.contractCall(contractName, "fulfil-listing-stx", [
                types.uint(0),
                types.principal(nftAssetContract)
            ], unintendedTaker.address), 
        ]);
        block.receipts[2].result.expectErr().expectUint(2006);
        assertEquals(block.receipts[2].events.length, 0);
    }
});
Clarinet.test({
    name: "Can fulfil multiple active listings in any order",
    fn (chain, accounts) {
        const deployer = accounts.get("deployer");
        const expiry = 100;
        const randomSorter = ()=>Math.random() - 0.5;
        // Take some makers and takers in random order.
        const makers = [
            "wallet_1",
            "wallet_2",
            "wallet_3",
            "wallet_4"
        ].sort(randomSorter).map((name)=>accounts.get(name));
        const takers = [
            "wallet_5",
            "wallet_6",
            "wallet_7",
            "wallet_8"
        ].sort(randomSorter).map((name)=>accounts.get(name));
        // Mint some NFTs so the IDs do not always start at zero.
        const mints = [
            ...Array(1 + ~~(Math.random() * 10))
        ].map(()=>mintNft({
                chain,
                deployer,
                recipient: deployer
            }));
        // Mint an NFT for all makers and generate orders.
        const nfts = makers.map((recipient)=>mintNft({
                chain,
                deployer,
                recipient
            }));
        const orders = makers.map((maker, i)=>({
                tokenId: nfts[i].tokenId,
                expiry,
                price: 1 + ~~(Math.random() * 10)
            }));
        // Whitelist asset contract
        chain.mineBlock([
            whitelistAssetTx(mints[0].nftAssetContract, true, deployer), 
        ]);
        // List all NFTs.
        const block = chain.mineBlock(makers.map((maker, i)=>listOrderTx(nfts[i].nftAssetContract, maker, makeOrder(orders[i]))));
        const orderIdUints = block.receipts.map((receipt)=>receipt.result.expectOk().toString());
        // Attempt to fulfil all listings.
        const block2 = chain.mineBlock(takers.map((taker, i)=>Tx.contractCall(contractName, "fulfil-listing-stx", [
                orderIdUints[i],
                types.principal(nfts[i].nftAssetContract)
            ], taker.address)));
        const contractAddress = contractPrincipal(deployer);
        // Assert that all orders were fulfilled and that the NFTs and STX have been tranferred to the appropriate principals.
        block2.receipts.map((receipt, i)=>{
            assertEquals(receipt.result.expectOk(), orderIdUints[i]);
            assertNftTransfer(receipt.events[0], nfts[i].nftAssetContract, nfts[i].tokenId, contractAddress, takers[i].address);
            receipt.events.expectSTXTransferEvent(orders[i].price, takers[i].address, makers[i].address);
        });
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vVXNlcnMvaHVnby9TaXRlcy9oaXJvL2NsYXJpdHktZXhhbXBsZXMvZXhhbXBsZXMvbmZ0LW1hcmtldHBsYWNlL3Rlc3RzL25mdC1tYXJrZXRwbGFjZV90ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENsYXJpbmV0LFxuICBUeCxcbiAgQ2hhaW4sXG4gIEFjY291bnQsXG4gIHR5cGVzLFxufSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9jbGFyaW5ldEB2MS41LjIvaW5kZXgudHNcIjtcbmltcG9ydCB7IGFzc2VydEVxdWFscyB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAMC4xODAuMC90ZXN0aW5nL2Fzc2VydHMudHNcIjtcblxuY29uc3QgY29udHJhY3ROYW1lID0gXCJ0aW55LW1hcmtldFwiO1xuXG5jb25zdCBkZWZhdWx0TmZ0QXNzZXRDb250cmFjdCA9XG4gIFwiU1AyUEFCQUY5RlRBSllORlpIOTNYRU5BSjhGVlk5OVJSTTUwRDJKRzkubmZ0LXRyYWl0XCI7XG5jb25zdCBkZWZhdWx0UGF5bWVudEFzc2V0Q29udHJhY3QgPSBcInNpcDAxMC10b2tlblwiO1xuXG5jb25zdCBjb250cmFjdFByaW5jaXBhbCA9IChkZXBsb3llcjogQWNjb3VudCkgPT5cbiAgYCR7ZGVwbG95ZXIuYWRkcmVzc30uJHtjb250cmFjdE5hbWV9YDtcblxuZnVuY3Rpb24gbWludE5mdCh7XG4gIGNoYWluLFxuICBkZXBsb3llcixcbiAgcmVjaXBpZW50LFxuICBuZnRBc3NldENvbnRyYWN0ID0gZGVmYXVsdE5mdEFzc2V0Q29udHJhY3QsXG59OiB7XG4gIGNoYWluOiBDaGFpbjtcbiAgZGVwbG95ZXI6IEFjY291bnQ7XG4gIHJlY2lwaWVudDogQWNjb3VudDtcbiAgbmZ0QXNzZXRDb250cmFjdD86IHN0cmluZztcbn0pIHtcbiAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgIFR4LmNvbnRyYWN0Q2FsbChcbiAgICAgIG5mdEFzc2V0Q29udHJhY3QsXG4gICAgICBcIm1pbnRcIixcbiAgICAgIFt0eXBlcy5wcmluY2lwYWwocmVjaXBpZW50LmFkZHJlc3MpXSxcbiAgICAgIGRlcGxveWVyLmFkZHJlc3NcbiAgICApLFxuICBdKTtcbiAgYmxvY2sucmVjZWlwdHNbMF0ucmVzdWx0LmV4cGVjdE9rKCk7XG4gIGNvbnN0IG5mdE1pbnRFdmVudCA9IGJsb2NrLnJlY2VpcHRzWzBdLmV2ZW50c1swXS5uZnRfbWludF9ldmVudDtcbiAgY29uc3QgW25mdEFzc2V0Q29udHJhY3RQcmluY2lwYWwsIG5mdEFzc2V0SWRdID1cbiAgICBuZnRNaW50RXZlbnQuYXNzZXRfaWRlbnRpZmllci5zcGxpdChcIjo6XCIpO1xuICByZXR1cm4ge1xuICAgIG5mdEFzc2V0Q29udHJhY3Q6IG5mdEFzc2V0Q29udHJhY3RQcmluY2lwYWwsXG4gICAgbmZ0QXNzZXRJZCxcbiAgICB0b2tlbklkOiBuZnRNaW50RXZlbnQudmFsdWUuc3Vic3RyKDEpLFxuICAgIGJsb2NrLFxuICB9O1xufVxuXG5mdW5jdGlvbiBtaW50RnQoe1xuICBjaGFpbixcbiAgZGVwbG95ZXIsXG4gIGFtb3VudCxcbiAgcmVjaXBpZW50LFxuICBwYXltZW50QXNzZXRDb250cmFjdCA9IGRlZmF1bHRQYXltZW50QXNzZXRDb250cmFjdCxcbn06IHtcbiAgY2hhaW46IENoYWluO1xuICBkZXBsb3llcjogQWNjb3VudDtcbiAgYW1vdW50OiBudW1iZXI7XG4gIHJlY2lwaWVudDogQWNjb3VudDtcbiAgcGF5bWVudEFzc2V0Q29udHJhY3Q/OiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICBwYXltZW50QXNzZXRDb250cmFjdCxcbiAgICAgIFwibWludFwiLFxuICAgICAgW3R5cGVzLnVpbnQoYW1vdW50KSwgdHlwZXMucHJpbmNpcGFsKHJlY2lwaWVudC5hZGRyZXNzKV0sXG4gICAgICBkZXBsb3llci5hZGRyZXNzXG4gICAgKSxcbiAgXSk7XG4gIGJsb2NrLnJlY2VpcHRzWzBdLnJlc3VsdC5leHBlY3RPaygpO1xuXG4gIGNvbnN0IGZ0TWludEV2ZW50ID0gYmxvY2sucmVjZWlwdHNbMF0uZXZlbnRzWzBdLmZ0X21pbnRfZXZlbnQ7XG4gIGNvbnN0IFtwYXltZW50QXNzZXRDb250cmFjdFByaW5jaXBhbCwgcGF5bWVudEFzc2V0SWRdID1cbiAgICBmdE1pbnRFdmVudC5hc3NldF9pZGVudGlmaWVyLnNwbGl0KFwiOjpcIik7XG4gIHJldHVybiB7XG4gICAgcGF5bWVudEFzc2V0Q29udHJhY3Q6IHBheW1lbnRBc3NldENvbnRyYWN0UHJpbmNpcGFsLFxuICAgIHBheW1lbnRBc3NldElkLFxuICAgIGJsb2NrLFxuICB9O1xufVxuXG5pbnRlcmZhY2UgU2lwMDA5TmZ0VHJhbnNmZXJFdmVudCB7XG4gIHR5cGU6IHN0cmluZztcbiAgbmZ0X3RyYW5zZmVyX2V2ZW50OiB7XG4gICAgYXNzZXRfaWRlbnRpZmllcjogc3RyaW5nO1xuICAgIHNlbmRlcjogc3RyaW5nO1xuICAgIHJlY2lwaWVudDogc3RyaW5nO1xuICAgIHZhbHVlOiBzdHJpbmc7XG4gIH07XG59XG5cbmZ1bmN0aW9uIGFzc2VydE5mdFRyYW5zZmVyKFxuICBldmVudDogU2lwMDA5TmZ0VHJhbnNmZXJFdmVudCxcbiAgbmZ0QXNzZXRDb250cmFjdDogc3RyaW5nLFxuICB0b2tlbklkOiBudW1iZXIsXG4gIHNlbmRlcjogc3RyaW5nLFxuICByZWNpcGllbnQ6IHN0cmluZ1xuKSB7XG4gIGFzc2VydEVxdWFscyh0eXBlb2YgZXZlbnQsIFwib2JqZWN0XCIpO1xuICBhc3NlcnRFcXVhbHMoZXZlbnQudHlwZSwgXCJuZnRfdHJhbnNmZXJfZXZlbnRcIik7XG4gIGFzc2VydEVxdWFscyhcbiAgICBldmVudC5uZnRfdHJhbnNmZXJfZXZlbnQuYXNzZXRfaWRlbnRpZmllci5zdWJzdHIoXG4gICAgICAwLFxuICAgICAgbmZ0QXNzZXRDb250cmFjdC5sZW5ndGhcbiAgICApLFxuICAgIG5mdEFzc2V0Q29udHJhY3RcbiAgKTtcbiAgZXZlbnQubmZ0X3RyYW5zZmVyX2V2ZW50LnNlbmRlci5leHBlY3RQcmluY2lwYWwoc2VuZGVyKTtcbiAgZXZlbnQubmZ0X3RyYW5zZmVyX2V2ZW50LnJlY2lwaWVudC5leHBlY3RQcmluY2lwYWwocmVjaXBpZW50KTtcbiAgZXZlbnQubmZ0X3RyYW5zZmVyX2V2ZW50LnZhbHVlLmV4cGVjdFVpbnQodG9rZW5JZCk7XG59XG5cbmludGVyZmFjZSBPcmRlciB7XG4gIHRha2VyPzogc3RyaW5nO1xuICB0b2tlbklkOiBudW1iZXI7XG4gIGV4cGlyeTogbnVtYmVyO1xuICBwcmljZTogbnVtYmVyO1xuICBwYXltZW50QXNzZXRDb250cmFjdD86IHN0cmluZztcbn1cblxuY29uc3QgbWFrZU9yZGVyID0gKG9yZGVyOiBPcmRlcikgPT5cbiAgdHlwZXMudHVwbGUoe1xuICAgIHRha2VyOiBvcmRlci50YWtlclxuICAgICAgPyB0eXBlcy5zb21lKHR5cGVzLnByaW5jaXBhbChvcmRlci50YWtlcikpXG4gICAgICA6IHR5cGVzLm5vbmUoKSxcbiAgICBcInRva2VuLWlkXCI6IHR5cGVzLnVpbnQob3JkZXIudG9rZW5JZCksXG4gICAgZXhwaXJ5OiB0eXBlcy51aW50KG9yZGVyLmV4cGlyeSksXG4gICAgcHJpY2U6IHR5cGVzLnVpbnQob3JkZXIucHJpY2UpLFxuICAgIFwicGF5bWVudC1hc3NldC1jb250cmFjdFwiOiBvcmRlci5wYXltZW50QXNzZXRDb250cmFjdFxuICAgICAgPyB0eXBlcy5zb21lKHR5cGVzLnByaW5jaXBhbChvcmRlci5wYXltZW50QXNzZXRDb250cmFjdCkpXG4gICAgICA6IHR5cGVzLm5vbmUoKSxcbiAgfSk7XG5cbmNvbnN0IHdoaXRlbGlzdEFzc2V0VHggPSAoXG4gIGFzc2V0Q29udHJhY3Q6IHN0cmluZyxcbiAgd2hpdGVsaXN0ZWQ6IGJvb2xlYW4sXG4gIGNvbnRyYWN0T3duZXI6IEFjY291bnRcbikgPT5cbiAgVHguY29udHJhY3RDYWxsKFxuICAgIGNvbnRyYWN0TmFtZSxcbiAgICBcInNldC13aGl0ZWxpc3RlZFwiLFxuICAgIFt0eXBlcy5wcmluY2lwYWwoYXNzZXRDb250cmFjdCksIHR5cGVzLmJvb2wod2hpdGVsaXN0ZWQpXSxcbiAgICBjb250cmFjdE93bmVyLmFkZHJlc3NcbiAgKTtcblxuY29uc3QgbGlzdE9yZGVyVHggPSAoXG4gIG5mdEFzc2V0Q29udHJhY3Q6IHN0cmluZyxcbiAgbWFrZXI6IEFjY291bnQsXG4gIG9yZGVyOiBPcmRlciB8IHN0cmluZ1xuKSA9PlxuICBUeC5jb250cmFjdENhbGwoXG4gICAgY29udHJhY3ROYW1lLFxuICAgIFwibGlzdC1hc3NldFwiLFxuICAgIFtcbiAgICAgIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KSxcbiAgICAgIHR5cGVvZiBvcmRlciA9PT0gXCJzdHJpbmdcIiA/IG9yZGVyIDogbWFrZU9yZGVyKG9yZGVyKSxcbiAgICBdLFxuICAgIG1ha2VyLmFkZHJlc3NcbiAgKTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiQ2FuIGxpc3QgYW4gTkZUIGZvciBzYWxlIGZvciBTVFhcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiAxMCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1sxXS5yZXN1bHQuZXhwZWN0T2soKS5leHBlY3RVaW50KDApO1xuICAgIGFzc2VydE5mdFRyYW5zZmVyKFxuICAgICAgYmxvY2sucmVjZWlwdHNbMV0uZXZlbnRzWzBdLFxuICAgICAgbmZ0QXNzZXRDb250cmFjdCxcbiAgICAgIHRva2VuSWQsXG4gICAgICBtYWtlci5hZGRyZXNzLFxuICAgICAgY29udHJhY3RQcmluY2lwYWwoZGVwbG95ZXIpXG4gICAgKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW4gbGlzdCBhbiBORlQgZm9yIHNhbGUgZm9yIGFueSBTSVAwMTAgZnVuZ2libGUgdG9rZW5cIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCB7IHBheW1lbnRBc3NldENvbnRyYWN0IH0gPSBtaW50RnQoe1xuICAgICAgY2hhaW4sXG4gICAgICBkZXBsb3llcixcbiAgICAgIHJlY2lwaWVudDogbWFrZXIsXG4gICAgICBhbW91bnQ6IDEsXG4gICAgfSk7XG4gICAgY29uc3Qgb3JkZXI6IE9yZGVyID0ge1xuICAgICAgdG9rZW5JZCxcbiAgICAgIGV4cGlyeTogMTAsXG4gICAgICBwcmljZTogMTAsXG4gICAgICBwYXltZW50QXNzZXRDb250cmFjdCxcbiAgICB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgd2hpdGVsaXN0QXNzZXRUeChwYXltZW50QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1syXS5yZXN1bHQuZXhwZWN0T2soKS5leHBlY3RVaW50KDApO1xuICAgIGFzc2VydE5mdFRyYW5zZmVyKFxuICAgICAgYmxvY2sucmVjZWlwdHNbMl0uZXZlbnRzWzBdLFxuICAgICAgbmZ0QXNzZXRDb250cmFjdCxcbiAgICAgIHRva2VuSWQsXG4gICAgICBtYWtlci5hZGRyZXNzLFxuICAgICAgY29udHJhY3RQcmluY2lwYWwoZGVwbG95ZXIpXG4gICAgKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW5ub3QgbGlzdCBhbiBORlQgZm9yIHNhbGUgaWYgdGhlIGV4cGlyeSBpcyBpbiB0aGUgcGFzdFwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IGV4cGlyeSA9IDEwO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5LCBwcmljZTogMTAgfTtcbiAgICBjaGFpbi5taW5lRW1wdHlCbG9ja1VudGlsKGV4cGlyeSArIDEpO1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1sxXS5yZXN1bHQuZXhwZWN0RXJyKCkuZXhwZWN0VWludCgxMDAwKTtcbiAgICBhc3NlcnRFcXVhbHMoYmxvY2sucmVjZWlwdHNbMV0uZXZlbnRzLmxlbmd0aCwgMCk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiQ2Fubm90IGxpc3QgYW4gTkZUIGZvciBzYWxlIGZvciBub3RoaW5nXCIsXG4gIGZuKGNoYWluOiBDaGFpbiwgYWNjb3VudHM6IE1hcDxzdHJpbmcsIEFjY291bnQ+KSB7XG4gICAgY29uc3QgW2RlcGxveWVyLCBtYWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCJdLm1hcChcbiAgICAgIChuYW1lKSA9PiBhY2NvdW50cy5nZXQobmFtZSkhXG4gICAgKTtcbiAgICBjb25zdCB7IG5mdEFzc2V0Q29udHJhY3QsIHRva2VuSWQgfSA9IG1pbnROZnQoe1xuICAgICAgY2hhaW4sXG4gICAgICBkZXBsb3llcixcbiAgICAgIHJlY2lwaWVudDogbWFrZXIsXG4gICAgfSk7XG4gICAgY29uc3Qgb3JkZXI6IE9yZGVyID0geyB0b2tlbklkLCBleHBpcnk6IDEwLCBwcmljZTogMCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1sxXS5yZXN1bHQuZXhwZWN0RXJyKCkuZXhwZWN0VWludCgxMDAxKTtcbiAgICBhc3NlcnRFcXVhbHMoYmxvY2sucmVjZWlwdHNbMV0uZXZlbnRzLmxlbmd0aCwgMCk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiQ2Fubm90IGxpc3QgYW4gTkZUIGZvciBzYWxlIHRoYXQgdGhlIHNlbmRlciBkb2VzIG5vdCBvd25cIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiB0YWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiAxMCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1sxXS5yZXN1bHQuZXhwZWN0RXJyKCkuZXhwZWN0VWludCgxKTtcbiAgICBhc3NlcnRFcXVhbHMoYmxvY2sucmVjZWlwdHNbMV0uZXZlbnRzLmxlbmd0aCwgMCk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiTWFrZXIgY2FuIGNhbmNlbCBhIGxpc3RpbmdcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiAxMCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcbiAgICAgICAgY29udHJhY3ROYW1lLFxuICAgICAgICBcImNhbmNlbC1saXN0aW5nXCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCldLFxuICAgICAgICBtYWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzJdLnJlc3VsdC5leHBlY3RPaygpLmV4cGVjdEJvb2wodHJ1ZSk7XG4gICAgYXNzZXJ0TmZ0VHJhbnNmZXIoXG4gICAgICBibG9jay5yZWNlaXB0c1syXS5ldmVudHNbMF0sXG4gICAgICBuZnRBc3NldENvbnRyYWN0LFxuICAgICAgdG9rZW5JZCxcbiAgICAgIGNvbnRyYWN0UHJpbmNpcGFsKGRlcGxveWVyKSxcbiAgICAgIG1ha2VyLmFkZHJlc3NcbiAgICApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIk5vbi1tYWtlciBjYW5ub3QgY2FuY2VsIGxpc3RpbmdcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCBvdGhlckFjY291bnRdID0gW1xuICAgICAgXCJkZXBsb3llclwiLFxuICAgICAgXCJ3YWxsZXRfMVwiLFxuICAgICAgXCJ3YWxsZXRfMlwiLFxuICAgIF0ubWFwKChuYW1lKSA9PiBhY2NvdW50cy5nZXQobmFtZSkhKTtcbiAgICBjb25zdCB7IG5mdEFzc2V0Q29udHJhY3QsIHRva2VuSWQgfSA9IG1pbnROZnQoe1xuICAgICAgY2hhaW4sXG4gICAgICBkZXBsb3llcixcbiAgICAgIHJlY2lwaWVudDogbWFrZXIsXG4gICAgfSk7XG4gICAgY29uc3Qgb3JkZXI6IE9yZGVyID0geyB0b2tlbklkLCBleHBpcnk6IDEwLCBwcmljZTogMTAgfTtcbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KG5mdEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJjYW5jZWwtbGlzdGluZ1wiLFxuICAgICAgICBbdHlwZXMudWludCgwKSwgdHlwZXMucHJpbmNpcGFsKG5mdEFzc2V0Q29udHJhY3QpXSxcbiAgICAgICAgb3RoZXJBY2NvdW50LmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbMl0ucmVzdWx0LmV4cGVjdEVycigpLmV4cGVjdFVpbnQoMjAwMSk7XG4gICAgYXNzZXJ0RXF1YWxzKGJsb2NrLnJlY2VpcHRzWzJdLmV2ZW50cy5sZW5ndGgsIDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbiBnZXQgbGlzdGluZ3MgdGhhdCBoYXZlIG5vdCBiZWVuIGNhbmNlbGxlZFwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5OiAxMCwgcHJpY2U6IDEwIH07XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgIF0pO1xuICAgIGNvbnN0IGxpc3RpbmdJZFVpbnQgPSBibG9jay5yZWNlaXB0c1sxXS5yZXN1bHQuZXhwZWN0T2soKTtcbiAgICBjb25zdCByZWNlaXB0ID0gY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICBjb250cmFjdE5hbWUsXG4gICAgICBcImdldC1saXN0aW5nXCIsXG4gICAgICBbbGlzdGluZ0lkVWludF0sXG4gICAgICBkZXBsb3llci5hZGRyZXNzXG4gICAgKTtcbiAgICBjb25zdCBsaXN0aW5nOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0gcmVjZWlwdC5yZXN1bHRcbiAgICAgIC5leHBlY3RTb21lKClcbiAgICAgIC5leHBlY3RUdXBsZSgpO1xuXG4gICAgbGlzdGluZy5leHBpcnkuZXhwZWN0VWludChvcmRlci5leHBpcnkpO1xuICAgIGxpc3RpbmcubWFrZXIuZXhwZWN0UHJpbmNpcGFsKG1ha2VyLmFkZHJlc3MpO1xuICAgIGxpc3RpbmcucHJpY2UuZXhwZWN0VWludChvcmRlci5wcmljZSk7XG4gICAgbGlzdGluZy50YWtlci5leHBlY3ROb25lKCk7XG4gICAgbGlzdGluZ1tcInBheW1lbnQtYXNzZXQtY29udHJhY3RcIl0uZXhwZWN0Tm9uZSgpO1xuICAgIGxpc3RpbmdbXCJuZnQtYXNzZXQtY29udHJhY3RcIl0uZXhwZWN0UHJpbmNpcGFsKG5mdEFzc2V0Q29udHJhY3QpO1xuICAgIGxpc3RpbmdbXCJ0b2tlbi1pZFwiXS5leHBlY3RVaW50KHRva2VuSWQpO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbm5vdCBnZXQgbGlzdGluZ3MgdGhhdCBoYXZlIGJlZW4gY2FuY2VsbGVkIG9yIGRvIG5vdCBleGlzdFwiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5OiAxMCwgcHJpY2U6IDEwIH07XG4gICAgY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJjYW5jZWwtbGlzdGluZ1wiLFxuICAgICAgICBbdHlwZXMudWludCgwKSwgdHlwZXMucHJpbmNpcGFsKG5mdEFzc2V0Q29udHJhY3QpXSxcbiAgICAgICAgbWFrZXIuYWRkcmVzc1xuICAgICAgKSxcbiAgICBdKTtcbiAgICBjb25zdCByZWNlaXB0cyA9IFt0eXBlcy51aW50KDApLCB0eXBlcy51aW50KDk5OSldLm1hcCgobGlzdGluZ0lkKSA9PlxuICAgICAgY2hhaW4uY2FsbFJlYWRPbmx5Rm4oXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJnZXQtbGlzdGluZ1wiLFxuICAgICAgICBbbGlzdGluZ0lkXSxcbiAgICAgICAgZGVwbG95ZXIuYWRkcmVzc1xuICAgICAgKVxuICAgICk7XG4gICAgcmVjZWlwdHMubWFwKChyZWNlaXB0KSA9PiByZWNlaXB0LnJlc3VsdC5leHBlY3ROb25lKCkpO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbiBmdWxmaWwgYW4gYWN0aXZlIGxpc3Rpbmcgd2l0aCBTVFhcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiAxMCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcbiAgICAgICAgY29udHJhY3ROYW1lLFxuICAgICAgICBcImZ1bGZpbC1saXN0aW5nLXN0eFwiLFxuICAgICAgICBbdHlwZXMudWludCgwKSwgdHlwZXMucHJpbmNpcGFsKG5mdEFzc2V0Q29udHJhY3QpXSxcbiAgICAgICAgdGFrZXIuYWRkcmVzc1xuICAgICAgKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1syXS5yZXN1bHQuZXhwZWN0T2soKS5leHBlY3RVaW50KDApO1xuICAgIGFzc2VydE5mdFRyYW5zZmVyKFxuICAgICAgYmxvY2sucmVjZWlwdHNbMl0uZXZlbnRzWzBdLFxuICAgICAgbmZ0QXNzZXRDb250cmFjdCxcbiAgICAgIHRva2VuSWQsXG4gICAgICBjb250cmFjdFByaW5jaXBhbChkZXBsb3llciksXG4gICAgICB0YWtlci5hZGRyZXNzXG4gICAgKTtcbiAgICBibG9jay5yZWNlaXB0c1syXS5ldmVudHMuZXhwZWN0U1RYVHJhbnNmZXJFdmVudChcbiAgICAgIG9yZGVyLnByaWNlLFxuICAgICAgdGFrZXIuYWRkcmVzcyxcbiAgICAgIG1ha2VyLmFkZHJlc3NcbiAgICApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbiBmdWxmaWwgYW4gYWN0aXZlIGxpc3Rpbmcgd2l0aCBTSVAwMTAgZnVuZ2libGUgdG9rZW5zXCIsXG4gIGZuKGNoYWluOiBDaGFpbiwgYWNjb3VudHM6IE1hcDxzdHJpbmcsIEFjY291bnQ+KSB7XG4gICAgY29uc3QgW2RlcGxveWVyLCBtYWtlciwgdGFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiLCBcIndhbGxldF8yXCJdLm1hcChcbiAgICAgIChuYW1lKSA9PiBhY2NvdW50cy5nZXQobmFtZSkhXG4gICAgKTtcbiAgICBjb25zdCBwcmljZSA9IDUwO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCB7IHBheW1lbnRBc3NldENvbnRyYWN0LCBwYXltZW50QXNzZXRJZCB9ID0gbWludEZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IHRha2VyLFxuICAgICAgYW1vdW50OiBwcmljZSxcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlLCBwYXltZW50QXNzZXRDb250cmFjdCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgd2hpdGVsaXN0QXNzZXRUeChwYXltZW50QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcbiAgICAgICAgY29udHJhY3ROYW1lLFxuICAgICAgICBcImZ1bGZpbC1saXN0aW5nLWZ0XCIsXG4gICAgICAgIFtcbiAgICAgICAgICB0eXBlcy51aW50KDApLFxuICAgICAgICAgIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KSxcbiAgICAgICAgICB0eXBlcy5wcmluY2lwYWwocGF5bWVudEFzc2V0Q29udHJhY3QpLFxuICAgICAgICBdLFxuICAgICAgICB0YWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzNdLnJlc3VsdC5leHBlY3RPaygpLmV4cGVjdFVpbnQoMCk7XG4gICAgYXNzZXJ0TmZ0VHJhbnNmZXIoXG4gICAgICBibG9jay5yZWNlaXB0c1szXS5ldmVudHNbMF0sXG4gICAgICBuZnRBc3NldENvbnRyYWN0LFxuICAgICAgdG9rZW5JZCxcbiAgICAgIGNvbnRyYWN0UHJpbmNpcGFsKGRlcGxveWVyKSxcbiAgICAgIHRha2VyLmFkZHJlc3NcbiAgICApO1xuICAgIGJsb2NrLnJlY2VpcHRzWzNdLmV2ZW50cy5leHBlY3RGdW5naWJsZVRva2VuVHJhbnNmZXJFdmVudChcbiAgICAgIHByaWNlLFxuICAgICAgdGFrZXIuYWRkcmVzcyxcbiAgICAgIG1ha2VyLmFkZHJlc3MsXG4gICAgICBwYXltZW50QXNzZXRJZFxuICAgICk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiQ2Fubm90IGZ1bGZpbCBvd24gbGlzdGluZ1wiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5OiAxMCwgcHJpY2U6IDEwIH07XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3Rpbmctc3R4XCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCldLFxuICAgICAgICBtYWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzJdLnJlc3VsdC5leHBlY3RFcnIoKS5leHBlY3RVaW50KDIwMDUpO1xuICAgIGFzc2VydEVxdWFscyhibG9jay5yZWNlaXB0c1syXS5ldmVudHMubGVuZ3RoLCAwKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW5ub3QgZnVsZmlsIGFuIHVua25vd24gbGlzdGluZ1wiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXIsIHRha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIiwgXCJ3YWxsZXRfMlwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0IH0gPSBtaW50TmZ0KHsgY2hhaW4sIGRlcGxveWVyLCByZWNpcGllbnQ6IG1ha2VyIH0pO1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3Rpbmctc3R4XCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCldLFxuICAgICAgICB0YWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzFdLnJlc3VsdC5leHBlY3RFcnIoKS5leHBlY3RVaW50KDIwMDApO1xuICAgIGFzc2VydEVxdWFscyhibG9jay5yZWNlaXB0c1sxXS5ldmVudHMubGVuZ3RoLCAwKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW5ub3QgZnVsZmlsIGFuIGV4cGlyZWQgbGlzdGluZ1wiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXIsIHRha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIiwgXCJ3YWxsZXRfMlwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgZXhwaXJ5ID0gMTA7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5LCBwcmljZTogMTAgfTtcbiAgICBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgIF0pO1xuICAgIGNoYWluLm1pbmVFbXB0eUJsb2NrVW50aWwoZXhwaXJ5ICsgMSk7XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3Rpbmctc3R4XCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCldLFxuICAgICAgICB0YWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzBdLnJlc3VsdC5leHBlY3RFcnIoKS5leHBlY3RVaW50KDIwMDIpO1xuICAgIGFzc2VydEVxdWFscyhibG9jay5yZWNlaXB0c1swXS5ldmVudHMubGVuZ3RoLCAwKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW5ub3QgZnVsZmlsIGEgbGlzdGluZyB3aXRoIGEgZGlmZmVyZW50IE5GVCBjb250cmFjdCByZWZlcmVuY2VcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IGV4cGlyeSA9IDEwO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiAxMCB9O1xuICAgIGNvbnN0IGJvZ3VzTmZ0QXNzZXRDb250cmFjdCA9IGAke2RlcGxveWVyLmFkZHJlc3N9LmJvZ3VzLW5mdGA7XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3Rpbmctc3R4XCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwoYm9ndXNOZnRBc3NldENvbnRyYWN0KV0sXG4gICAgICAgIHRha2VyLmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbMl0ucmVzdWx0LmV4cGVjdEVycigpLmV4cGVjdFVpbnQoMjAwMyk7XG4gICAgYXNzZXJ0RXF1YWxzKGJsb2NrLnJlY2VpcHRzWzJdLmV2ZW50cy5sZW5ndGgsIDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbm5vdCBmdWxmaWwgYW4gYWN0aXZlIFNUWCBsaXN0aW5nIHdpdGggU0lQMDEwIGZ1bmdpYmxlIHRva2Vuc1wiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXIsIHRha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIiwgXCJ3YWxsZXRfMlwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgcHJpY2UgPSA1MDtcbiAgICBjb25zdCB7IG5mdEFzc2V0Q29udHJhY3QsIHRva2VuSWQgfSA9IG1pbnROZnQoe1xuICAgICAgY2hhaW4sXG4gICAgICBkZXBsb3llcixcbiAgICAgIHJlY2lwaWVudDogbWFrZXIsXG4gICAgfSk7XG4gICAgY29uc3QgeyBwYXltZW50QXNzZXRDb250cmFjdCB9ID0gbWludEZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IHRha2VyLFxuICAgICAgYW1vdW50OiBwcmljZSxcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlIH07XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KHBheW1lbnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3RpbmctZnRcIixcbiAgICAgICAgW1xuICAgICAgICAgIHR5cGVzLnVpbnQoMCksXG4gICAgICAgICAgdHlwZXMucHJpbmNpcGFsKG5mdEFzc2V0Q29udHJhY3QpLFxuICAgICAgICAgIHR5cGVzLnByaW5jaXBhbChwYXltZW50QXNzZXRDb250cmFjdCksXG4gICAgICAgIF0sXG4gICAgICAgIHRha2VyLmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbM10ucmVzdWx0LmV4cGVjdEVycigpLmV4cGVjdFVpbnQoMjAwNCk7XG4gICAgYXNzZXJ0RXF1YWxzKGJsb2NrLnJlY2VpcHRzWzNdLmV2ZW50cy5sZW5ndGgsIDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbm5vdCBmdWxmaWwgYW4gYWN0aXZlIFNJUDAxMCBmdW5naWJsZSB0b2tlbiBsaXN0aW5nIHdpdGggU1RYXCIsXG4gIGZuKGNoYWluOiBDaGFpbiwgYWNjb3VudHM6IE1hcDxzdHJpbmcsIEFjY291bnQ+KSB7XG4gICAgY29uc3QgW2RlcGxveWVyLCBtYWtlciwgdGFrZXJdID0gW1wiZGVwbG95ZXJcIiwgXCJ3YWxsZXRfMVwiLCBcIndhbGxldF8yXCJdLm1hcChcbiAgICAgIChuYW1lKSA9PiBhY2NvdW50cy5nZXQobmFtZSkhXG4gICAgKTtcbiAgICBjb25zdCBwcmljZSA9IDUwO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCB7IHBheW1lbnRBc3NldENvbnRyYWN0IH0gPSBtaW50RnQoe1xuICAgICAgY2hhaW4sXG4gICAgICBkZXBsb3llcixcbiAgICAgIHJlY2lwaWVudDogdGFrZXIsXG4gICAgICBhbW91bnQ6IHByaWNlLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHsgdG9rZW5JZCwgZXhwaXJ5OiAxMCwgcHJpY2UsIHBheW1lbnRBc3NldENvbnRyYWN0IH07XG4gICAgY29uc3QgYmxvY2sgPSBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChuZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KHBheW1lbnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgICBsaXN0T3JkZXJUeChuZnRBc3NldENvbnRyYWN0LCBtYWtlciwgb3JkZXIpLFxuICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICBjb250cmFjdE5hbWUsXG4gICAgICAgIFwiZnVsZmlsLWxpc3Rpbmctc3R4XCIsXG4gICAgICAgIFt0eXBlcy51aW50KDApLCB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCldLFxuICAgICAgICB0YWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzNdLnJlc3VsdC5leHBlY3RFcnIoKS5leHBlY3RVaW50KDIwMDQpO1xuICAgIGFzc2VydEVxdWFscyhibG9jay5yZWNlaXB0c1szXS5ldmVudHMubGVuZ3RoLCAwKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW5ub3QgZnVsZmlsIGFuIGFjdGl2ZSBTSVAwMTAgZnVuZ2libGUgdG9rZW4gbGlzdGluZyB3aXRoIGEgZGlmZmVyZW50IFNJUDAxMCBmdW5naWJsZSB0b2tlbiBjb250cmFjdCByZWZlcmVuY2VcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHByaWNlID0gNTA7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcGF5bWVudEFzc2V0Q29udHJhY3QgfSA9IG1pbnRGdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiB0YWtlcixcbiAgICAgIGFtb3VudDogcHJpY2UsXG4gICAgfSk7XG4gICAgY29uc3QgYm9ndXNQYXltZW50QXNzZXRDb250cmFjdCA9IGAke2RlcGxveWVyLmFkZHJlc3N9LmJvZ3VzLWZ0YDtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlLCBwYXltZW50QXNzZXRDb250cmFjdCB9O1xuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFtcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgobmZ0QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgd2hpdGVsaXN0QXNzZXRUeChwYXltZW50QXNzZXRDb250cmFjdCwgdHJ1ZSwgZGVwbG95ZXIpLFxuICAgICAgbGlzdE9yZGVyVHgobmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG9yZGVyKSxcbiAgICAgIFR4LmNvbnRyYWN0Q2FsbChcbiAgICAgICAgY29udHJhY3ROYW1lLFxuICAgICAgICBcImZ1bGZpbC1saXN0aW5nLWZ0XCIsXG4gICAgICAgIFtcbiAgICAgICAgICB0eXBlcy51aW50KDApLFxuICAgICAgICAgIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KSxcbiAgICAgICAgICB0eXBlcy5wcmluY2lwYWwoYm9ndXNQYXltZW50QXNzZXRDb250cmFjdCksXG4gICAgICAgIF0sXG4gICAgICAgIHRha2VyLmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbM10ucmVzdWx0LmV4cGVjdEVycigpLmV4cGVjdFVpbnQoMjAwNCk7XG4gICAgYXNzZXJ0RXF1YWxzKGJsb2NrLnJlY2VpcHRzWzNdLmV2ZW50cy5sZW5ndGgsIDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbm5vdCBmdWxmaWwgYW4gYWN0aXZlIFNUWCBsaXN0aW5nIHdpdGggaW5zdWZmaWNpZW50IGJhbGFuY2VcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHsgbmZ0QXNzZXRDb250cmFjdCwgdG9rZW5JZCB9ID0gbWludE5mdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiBtYWtlcixcbiAgICB9KTtcbiAgICBjb25zdCBvcmRlcjogT3JkZXIgPSB7IHRva2VuSWQsIGV4cGlyeTogMTAsIHByaWNlOiB0YWtlci5iYWxhbmNlICsgMTAgfTtcbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KG5mdEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJmdWxmaWwtbGlzdGluZy1zdHhcIixcbiAgICAgICAgW3R5cGVzLnVpbnQoMCksIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KV0sXG4gICAgICAgIHRha2VyLmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbMl0ucmVzdWx0LmV4cGVjdEVycigpLmV4cGVjdFVpbnQoMSk7XG4gICAgYXNzZXJ0RXF1YWxzKGJsb2NrLnJlY2VpcHRzWzJdLmV2ZW50cy5sZW5ndGgsIDApO1xuICB9LFxufSk7XG5cbkNsYXJpbmV0LnRlc3Qoe1xuICBuYW1lOiBcIkNhbm5vdCBmdWxmaWwgYW4gYWN0aXZlIFNJUDAxMCBmdW5naWJsZSB0b2tlbiBsaXN0aW5nIHdpdGggaW5zdWZmaWNpZW50IGJhbGFuY2VcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlcl0gPSBbXCJkZXBsb3llclwiLCBcIndhbGxldF8xXCIsIFwid2FsbGV0XzJcIl0ubWFwKFxuICAgICAgKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSFcbiAgICApO1xuICAgIGNvbnN0IHByaWNlID0gNTA7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcGF5bWVudEFzc2V0Q29udHJhY3QgfSA9IG1pbnRGdCh7XG4gICAgICBjaGFpbixcbiAgICAgIGRlcGxveWVyLFxuICAgICAgcmVjaXBpZW50OiB0YWtlcixcbiAgICAgIGFtb3VudDogcHJpY2UsXG4gICAgfSk7XG4gICAgY29uc3Qgb3JkZXI6IE9yZGVyID0ge1xuICAgICAgdG9rZW5JZCxcbiAgICAgIGV4cGlyeTogMTAsXG4gICAgICBwcmljZTogdGFrZXIuYmFsYW5jZSArIDEwLFxuICAgICAgcGF5bWVudEFzc2V0Q29udHJhY3QsXG4gICAgfTtcbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KG5mdEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIHdoaXRlbGlzdEFzc2V0VHgocGF5bWVudEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJmdWxmaWwtbGlzdGluZy1mdFwiLFxuICAgICAgICBbXG4gICAgICAgICAgdHlwZXMudWludCgwKSxcbiAgICAgICAgICB0eXBlcy5wcmluY2lwYWwobmZ0QXNzZXRDb250cmFjdCksXG4gICAgICAgICAgdHlwZXMucHJpbmNpcGFsKHBheW1lbnRBc3NldENvbnRyYWN0KSxcbiAgICAgICAgXSxcbiAgICAgICAgdGFrZXIuYWRkcmVzc1xuICAgICAgKSxcbiAgICBdKTtcbiAgICBibG9jay5yZWNlaXB0c1szXS5yZXN1bHQuZXhwZWN0RXJyKCkuZXhwZWN0VWludCgxKTtcbiAgICBhc3NlcnRFcXVhbHMoYmxvY2sucmVjZWlwdHNbM10uZXZlbnRzLmxlbmd0aCwgMCk7XG4gIH0sXG59KTtcblxuQ2xhcmluZXQudGVzdCh7XG4gIG5hbWU6IFwiSW50ZW5kZWQgdGFrZXIgY2FuIGZ1bGZpbCBhY3RpdmUgbGlzdGluZ1wiLFxuICBmbihjaGFpbjogQ2hhaW4sIGFjY291bnRzOiBNYXA8c3RyaW5nLCBBY2NvdW50Pikge1xuICAgIGNvbnN0IFtkZXBsb3llciwgbWFrZXIsIHRha2VyXSA9IFtcImRlcGxveWVyXCIsIFwid2FsbGV0XzFcIiwgXCJ3YWxsZXRfMlwiXS5tYXAoXG4gICAgICAobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpIVxuICAgICk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHtcbiAgICAgIHRva2VuSWQsXG4gICAgICBleHBpcnk6IDEwLFxuICAgICAgcHJpY2U6IDEwLFxuICAgICAgdGFrZXI6IHRha2VyLmFkZHJlc3MsXG4gICAgfTtcbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KG5mdEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJmdWxmaWwtbGlzdGluZy1zdHhcIixcbiAgICAgICAgW3R5cGVzLnVpbnQoMCksIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KV0sXG4gICAgICAgIHRha2VyLmFkZHJlc3NcbiAgICAgICksXG4gICAgXSk7XG4gICAgYmxvY2sucmVjZWlwdHNbMl0ucmVzdWx0LmV4cGVjdE9rKCkuZXhwZWN0VWludCgwKTtcbiAgICBhc3NlcnROZnRUcmFuc2ZlcihcbiAgICAgIGJsb2NrLnJlY2VpcHRzWzJdLmV2ZW50c1swXSxcbiAgICAgIG5mdEFzc2V0Q29udHJhY3QsXG4gICAgICB0b2tlbklkLFxuICAgICAgY29udHJhY3RQcmluY2lwYWwoZGVwbG95ZXIpLFxuICAgICAgdGFrZXIuYWRkcmVzc1xuICAgICk7XG4gICAgYmxvY2sucmVjZWlwdHNbMl0uZXZlbnRzLmV4cGVjdFNUWFRyYW5zZmVyRXZlbnQoXG4gICAgICBvcmRlci5wcmljZSxcbiAgICAgIHRha2VyLmFkZHJlc3MsXG4gICAgICBtYWtlci5hZGRyZXNzXG4gICAgKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJVbmludGVuZGVkIHRha2VyIGNhbm5vdCBmdWxmaWwgYWN0aXZlIGxpc3RpbmdcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBbZGVwbG95ZXIsIG1ha2VyLCB0YWtlciwgdW5pbnRlbmRlZFRha2VyXSA9IFtcbiAgICAgIFwiZGVwbG95ZXJcIixcbiAgICAgIFwid2FsbGV0XzFcIixcbiAgICAgIFwid2FsbGV0XzJcIixcbiAgICAgIFwid2FsbGV0XzNcIixcbiAgICBdLm1hcCgobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpISk7XG4gICAgY29uc3QgeyBuZnRBc3NldENvbnRyYWN0LCB0b2tlbklkIH0gPSBtaW50TmZ0KHtcbiAgICAgIGNoYWluLFxuICAgICAgZGVwbG95ZXIsXG4gICAgICByZWNpcGllbnQ6IG1ha2VyLFxuICAgIH0pO1xuICAgIGNvbnN0IG9yZGVyOiBPcmRlciA9IHtcbiAgICAgIHRva2VuSWQsXG4gICAgICBleHBpcnk6IDEwLFxuICAgICAgcHJpY2U6IDEwLFxuICAgICAgdGFrZXI6IHRha2VyLmFkZHJlc3MsXG4gICAgfTtcbiAgICBjb25zdCBibG9jayA9IGNoYWluLm1pbmVCbG9jayhbXG4gICAgICB3aGl0ZWxpc3RBc3NldFR4KG5mdEFzc2V0Q29udHJhY3QsIHRydWUsIGRlcGxveWVyKSxcbiAgICAgIGxpc3RPcmRlclR4KG5mdEFzc2V0Q29udHJhY3QsIG1ha2VyLCBvcmRlciksXG4gICAgICBUeC5jb250cmFjdENhbGwoXG4gICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgXCJmdWxmaWwtbGlzdGluZy1zdHhcIixcbiAgICAgICAgW3R5cGVzLnVpbnQoMCksIHR5cGVzLnByaW5jaXBhbChuZnRBc3NldENvbnRyYWN0KV0sXG4gICAgICAgIHVuaW50ZW5kZWRUYWtlci5hZGRyZXNzXG4gICAgICApLFxuICAgIF0pO1xuICAgIGJsb2NrLnJlY2VpcHRzWzJdLnJlc3VsdC5leHBlY3RFcnIoKS5leHBlY3RVaW50KDIwMDYpO1xuICAgIGFzc2VydEVxdWFscyhibG9jay5yZWNlaXB0c1syXS5ldmVudHMubGVuZ3RoLCAwKTtcbiAgfSxcbn0pO1xuXG5DbGFyaW5ldC50ZXN0KHtcbiAgbmFtZTogXCJDYW4gZnVsZmlsIG11bHRpcGxlIGFjdGl2ZSBsaXN0aW5ncyBpbiBhbnkgb3JkZXJcIixcbiAgZm4oY2hhaW46IENoYWluLCBhY2NvdW50czogTWFwPHN0cmluZywgQWNjb3VudD4pIHtcbiAgICBjb25zdCBkZXBsb3llciA9IGFjY291bnRzLmdldChcImRlcGxveWVyXCIpITtcbiAgICBjb25zdCBleHBpcnkgPSAxMDA7XG5cbiAgICBjb25zdCByYW5kb21Tb3J0ZXIgPSAoKSA9PiBNYXRoLnJhbmRvbSgpIC0gMC41O1xuXG4gICAgLy8gVGFrZSBzb21lIG1ha2VycyBhbmQgdGFrZXJzIGluIHJhbmRvbSBvcmRlci5cbiAgICBjb25zdCBtYWtlcnMgPSBbXCJ3YWxsZXRfMVwiLCBcIndhbGxldF8yXCIsIFwid2FsbGV0XzNcIiwgXCJ3YWxsZXRfNFwiXVxuICAgICAgLnNvcnQocmFuZG9tU29ydGVyKVxuICAgICAgLm1hcCgobmFtZSkgPT4gYWNjb3VudHMuZ2V0KG5hbWUpISk7XG4gICAgY29uc3QgdGFrZXJzID0gW1wid2FsbGV0XzVcIiwgXCJ3YWxsZXRfNlwiLCBcIndhbGxldF83XCIsIFwid2FsbGV0XzhcIl1cbiAgICAgIC5zb3J0KHJhbmRvbVNvcnRlcilcbiAgICAgIC5tYXAoKG5hbWUpID0+IGFjY291bnRzLmdldChuYW1lKSEpO1xuXG4gICAgLy8gTWludCBzb21lIE5GVHMgc28gdGhlIElEcyBkbyBub3QgYWx3YXlzIHN0YXJ0IGF0IHplcm8uXG4gICAgY29uc3QgbWludHMgPSBbLi4uQXJyYXkoMSArIH5+KE1hdGgucmFuZG9tKCkgKiAxMCkpXS5tYXAoKCkgPT5cbiAgICAgIG1pbnROZnQoeyBjaGFpbiwgZGVwbG95ZXIsIHJlY2lwaWVudDogZGVwbG95ZXIgfSlcbiAgICApO1xuXG4gICAgLy8gTWludCBhbiBORlQgZm9yIGFsbCBtYWtlcnMgYW5kIGdlbmVyYXRlIG9yZGVycy5cbiAgICBjb25zdCBuZnRzID0gbWFrZXJzLm1hcCgocmVjaXBpZW50KSA9PlxuICAgICAgbWludE5mdCh7IGNoYWluLCBkZXBsb3llciwgcmVjaXBpZW50IH0pXG4gICAgKTtcbiAgICBjb25zdCBvcmRlcnM6IE9yZGVyW10gPSBtYWtlcnMubWFwKChtYWtlciwgaSkgPT4gKHtcbiAgICAgIHRva2VuSWQ6IG5mdHNbaV0udG9rZW5JZCxcbiAgICAgIGV4cGlyeSxcbiAgICAgIHByaWNlOiAxICsgfn4oTWF0aC5yYW5kb20oKSAqIDEwKSxcbiAgICB9KSk7XG5cbiAgICAvLyBXaGl0ZWxpc3QgYXNzZXQgY29udHJhY3RcbiAgICBjaGFpbi5taW5lQmxvY2soW1xuICAgICAgd2hpdGVsaXN0QXNzZXRUeChtaW50c1swXS5uZnRBc3NldENvbnRyYWN0LCB0cnVlLCBkZXBsb3llciksXG4gICAgXSk7XG5cbiAgICAvLyBMaXN0IGFsbCBORlRzLlxuICAgIGNvbnN0IGJsb2NrID0gY2hhaW4ubWluZUJsb2NrKFxuICAgICAgbWFrZXJzLm1hcCgobWFrZXIsIGkpID0+XG4gICAgICAgIGxpc3RPcmRlclR4KG5mdHNbaV0ubmZ0QXNzZXRDb250cmFjdCwgbWFrZXIsIG1ha2VPcmRlcihvcmRlcnNbaV0pKVxuICAgICAgKVxuICAgICk7XG4gICAgY29uc3Qgb3JkZXJJZFVpbnRzID0gYmxvY2sucmVjZWlwdHMubWFwKChyZWNlaXB0KSA9PlxuICAgICAgcmVjZWlwdC5yZXN1bHQuZXhwZWN0T2soKS50b1N0cmluZygpXG4gICAgKTtcblxuICAgIC8vIEF0dGVtcHQgdG8gZnVsZmlsIGFsbCBsaXN0aW5ncy5cbiAgICBjb25zdCBibG9jazIgPSBjaGFpbi5taW5lQmxvY2soXG4gICAgICB0YWtlcnMubWFwKCh0YWtlciwgaSkgPT5cbiAgICAgICAgVHguY29udHJhY3RDYWxsKFxuICAgICAgICAgIGNvbnRyYWN0TmFtZSxcbiAgICAgICAgICBcImZ1bGZpbC1saXN0aW5nLXN0eFwiLFxuICAgICAgICAgIFtvcmRlcklkVWludHNbaV0sIHR5cGVzLnByaW5jaXBhbChuZnRzW2ldLm5mdEFzc2V0Q29udHJhY3QpXSxcbiAgICAgICAgICB0YWtlci5hZGRyZXNzXG4gICAgICAgIClcbiAgICAgIClcbiAgICApO1xuXG4gICAgY29uc3QgY29udHJhY3RBZGRyZXNzID0gY29udHJhY3RQcmluY2lwYWwoZGVwbG95ZXIpO1xuXG4gICAgLy8gQXNzZXJ0IHRoYXQgYWxsIG9yZGVycyB3ZXJlIGZ1bGZpbGxlZCBhbmQgdGhhdCB0aGUgTkZUcyBhbmQgU1RYIGhhdmUgYmVlbiB0cmFuZmVycmVkIHRvIHRoZSBhcHByb3ByaWF0ZSBwcmluY2lwYWxzLlxuICAgIGJsb2NrMi5yZWNlaXB0cy5tYXAoKHJlY2VpcHQsIGkpID0+IHtcbiAgICAgIGFzc2VydEVxdWFscyhyZWNlaXB0LnJlc3VsdC5leHBlY3RPaygpLCBvcmRlcklkVWludHNbaV0pO1xuICAgICAgYXNzZXJ0TmZ0VHJhbnNmZXIoXG4gICAgICAgIHJlY2VpcHQuZXZlbnRzWzBdLFxuICAgICAgICBuZnRzW2ldLm5mdEFzc2V0Q29udHJhY3QsXG4gICAgICAgIG5mdHNbaV0udG9rZW5JZCxcbiAgICAgICAgY29udHJhY3RBZGRyZXNzLFxuICAgICAgICB0YWtlcnNbaV0uYWRkcmVzc1xuICAgICAgKTtcbiAgICAgIHJlY2VpcHQuZXZlbnRzLmV4cGVjdFNUWFRyYW5zZmVyRXZlbnQoXG4gICAgICAgIG9yZGVyc1tpXS5wcmljZSxcbiAgICAgICAgdGFrZXJzW2ldLmFkZHJlc3MsXG4gICAgICAgIG1ha2Vyc1tpXS5hZGRyZXNzXG4gICAgICApO1xuICAgIH0pO1xuICB9LFxufSk7XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsU0FDRSxRQUFRLEVBQ1IsRUFBRSxFQUdGLEtBQUssUUFDQSw4Q0FBOEMsQ0FBQztBQUN0RCxTQUFTLFlBQVksUUFBUSxrREFBa0QsQ0FBQztBQUVoRixNQUFNLFlBQVksR0FBRyxhQUFhLEFBQUM7QUFFbkMsTUFBTSx1QkFBdUIsR0FDM0IscURBQXFELEFBQUM7QUFDeEQsTUFBTSwyQkFBMkIsR0FBRyxjQUFjLEFBQUM7QUFFbkQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFFBQWlCLEdBQzFDLENBQUMsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxBQUFDO0FBRXhDLFNBQVMsT0FBTyxDQUFDLEVBQ2YsS0FBSyxDQUFBLEVBQ0wsUUFBUSxDQUFBLEVBQ1IsU0FBUyxDQUFBLEVBQ1QsZ0JBQWdCLEVBQUcsdUJBQXVCLENBQUEsRUFNM0MsRUFBRTtJQUNELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDNUIsRUFBRSxDQUFDLFlBQVksQ0FDYixnQkFBZ0IsRUFDaEIsTUFBTSxFQUNOO1lBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDO1NBQUMsRUFDcEMsUUFBUSxDQUFDLE9BQU8sQ0FDakI7S0FDRixDQUFDLEFBQUM7SUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQyxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLEFBQUM7SUFDaEUsTUFBTSxDQUFDLHlCQUF5QixFQUFFLFVBQVUsQ0FBQyxHQUMzQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxBQUFDO0lBQzVDLE9BQU87UUFDTCxnQkFBZ0IsRUFBRSx5QkFBeUI7UUFDM0MsVUFBVTtRQUNWLE9BQU8sRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDckMsS0FBSztLQUNOLENBQUM7Q0FDSDtBQUVELFNBQVMsTUFBTSxDQUFDLEVBQ2QsS0FBSyxDQUFBLEVBQ0wsUUFBUSxDQUFBLEVBQ1IsTUFBTSxDQUFBLEVBQ04sU0FBUyxDQUFBLEVBQ1Qsb0JBQW9CLEVBQUcsMkJBQTJCLENBQUEsRUFPbkQsRUFBRTtJQUNELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDNUIsRUFBRSxDQUFDLFlBQVksQ0FDYixvQkFBb0IsRUFDcEIsTUFBTSxFQUNOO1lBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7WUFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7U0FBQyxFQUN4RCxRQUFRLENBQUMsT0FBTyxDQUNqQjtLQUNGLENBQUMsQUFBQztJQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBRXBDLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQUFBQztJQUM5RCxNQUFNLENBQUMsNkJBQTZCLEVBQUUsY0FBYyxDQUFDLEdBQ25ELFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEFBQUM7SUFDM0MsT0FBTztRQUNMLG9CQUFvQixFQUFFLDZCQUE2QjtRQUNuRCxjQUFjO1FBQ2QsS0FBSztLQUNOLENBQUM7Q0FDSDtBQVlELFNBQVMsaUJBQWlCLENBQ3hCLEtBQTZCLEVBQzdCLGdCQUF3QixFQUN4QixPQUFlLEVBQ2YsTUFBYyxFQUNkLFNBQWlCLEVBQ2pCO0lBQ0EsWUFBWSxDQUFDLE9BQU8sS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLG9CQUFvQixDQUFDLENBQUM7SUFDL0MsWUFBWSxDQUNWLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQzlDLENBQUMsRUFDRCxnQkFBZ0IsQ0FBQyxNQUFNLENBQ3hCLEVBQ0QsZ0JBQWdCLENBQ2pCLENBQUM7SUFDRixLQUFLLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4RCxLQUFLLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM5RCxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztDQUNwRDtBQVVELE1BQU0sU0FBUyxHQUFHLENBQUMsS0FBWSxHQUM3QixLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ1YsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEdBQ2QsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUN4QyxLQUFLLENBQUMsSUFBSSxFQUFFO1FBQ2hCLFVBQVUsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDckMsTUFBTSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNoQyxLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzlCLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxvQkFBb0IsR0FDaEQsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEdBQ3ZELEtBQUssQ0FBQyxJQUFJLEVBQUU7S0FDakIsQ0FBQyxBQUFDO0FBRUwsTUFBTSxnQkFBZ0IsR0FBRyxDQUN2QixhQUFxQixFQUNyQixXQUFvQixFQUNwQixhQUFzQixHQUV0QixFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixpQkFBaUIsRUFDakI7UUFBQyxLQUFLLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQztRQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO0tBQUMsRUFDekQsYUFBYSxDQUFDLE9BQU8sQ0FDdEIsQUFBQztBQUVKLE1BQU0sV0FBVyxHQUFHLENBQ2xCLGdCQUF3QixFQUN4QixLQUFjLEVBQ2QsS0FBcUIsR0FFckIsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osWUFBWSxFQUNaO1FBQ0UsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNqQyxPQUFPLEtBQUssS0FBSyxRQUFRLEdBQUcsS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUM7S0FDckQsRUFDRCxLQUFLLENBQUMsT0FBTyxDQUNkLEFBQUM7QUFFSixRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLGtDQUFrQztJQUN4QyxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FBQyxHQUFHLENBQ3BELENBQUMsSUFBSSxHQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEFBQUMsQ0FDOUIsQUFBQztRQUNGLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQSxFQUFFLE9BQU8sQ0FBQSxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQzVDLEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQVU7WUFBRSxPQUFPO1lBQUUsTUFBTSxFQUFFLEVBQUU7WUFBRSxLQUFLLEVBQUUsRUFBRTtTQUFFLEFBQUM7UUFDeEQsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ2xELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1NBQzVDLENBQUMsQUFBQztRQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNsRCxpQkFBaUIsQ0FDZixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDM0IsZ0JBQWdCLEVBQ2hCLE9BQU8sRUFDUCxLQUFLLENBQUMsT0FBTyxFQUNiLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUM1QixDQUFDO0tBQ0g7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLHdEQUF3RDtJQUM5RCxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FBQyxHQUFHLENBQ3BELENBQUMsSUFBSSxHQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEFBQUMsQ0FDOUIsQUFBQztRQUNGLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQSxFQUFFLE9BQU8sQ0FBQSxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQzVDLEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxFQUFFLG9CQUFvQixDQUFBLEVBQUUsR0FBRyxNQUFNLENBQUM7WUFDdEMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztZQUNoQixNQUFNLEVBQUUsQ0FBQztTQUNWLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQ25CLE9BQU87WUFDUCxNQUFNLEVBQUUsRUFBRTtZQUNWLEtBQUssRUFBRSxFQUFFO1lBQ1Qsb0JBQW9CO1NBQ3JCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsZ0JBQWdCLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUN0RCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztTQUM1QyxDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEQsaUJBQWlCLENBQ2YsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQzNCLGdCQUFnQixFQUNoQixPQUFPLEVBQ1AsS0FBSyxDQUFDLE9BQU8sRUFDYixpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FDNUIsQ0FBQztLQUNIO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSwwREFBMEQ7SUFDaEUsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUNwRCxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sTUFBTSxHQUFHLEVBQUUsQUFBQztRQUNsQixNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNO1lBQUUsS0FBSyxFQUFFLEVBQUU7U0FBRSxBQUFDO1FBQ3BELEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ2xELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1NBQzVDLENBQUMsQUFBQztRQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0RCxZQUFZLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO0tBQ2xEO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSx5Q0FBeUM7SUFDL0MsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUNwRCxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQUUsT0FBTztZQUFFLE1BQU0sRUFBRSxFQUFFO1lBQUUsS0FBSyxFQUFFLENBQUM7U0FBRSxBQUFDO1FBQ3ZELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztTQUM1QyxDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsMERBQTBEO0lBQ2hFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQUUsT0FBTztZQUFFLE1BQU0sRUFBRSxFQUFFO1lBQUUsS0FBSyxFQUFFLEVBQUU7U0FBRSxBQUFDO1FBQ3hELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztTQUM1QyxDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsNEJBQTRCO0lBQ2xDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQUMsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDcEQsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUssRUFBRSxFQUFFO1NBQUUsQUFBQztRQUN4RCxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osZ0JBQWdCLEVBQ2hCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JELGlCQUFpQixDQUNmLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUMzQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUNQLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUMzQixLQUFLLENBQUMsT0FBTyxDQUNkLENBQUM7S0FDSDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsaUNBQWlDO0lBQ3ZDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxZQUFZLENBQUMsR0FBRztZQUN0QyxVQUFVO1lBQ1YsVUFBVTtZQUNWLFVBQVU7U0FDWCxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQUMsQUFBQztRQUNyQyxNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQUUsT0FBTztZQUFFLE1BQU0sRUFBRSxFQUFFO1lBQUUsS0FBSyxFQUFFLEVBQUU7U0FBRSxBQUFDO1FBQ3hELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztZQUMzQyxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixnQkFBZ0IsRUFDaEI7Z0JBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUFDLEVBQ2xELFlBQVksQ0FBQyxPQUFPLENBQ3JCO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RELFlBQVksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDbEQ7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLCtDQUErQztJQUNyRCxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FBQyxHQUFHLENBQ3BELENBQUMsSUFBSSxHQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEFBQUMsQ0FDOUIsQUFBQztRQUNGLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQSxFQUFFLE9BQU8sQ0FBQSxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQzVDLEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQVU7WUFBRSxPQUFPO1lBQUUsTUFBTSxFQUFFLEVBQUU7WUFBRSxLQUFLLEVBQUUsRUFBRTtTQUFFLEFBQUM7UUFDeEQsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ2xELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1NBQzVDLENBQUMsQUFBQztRQUNILE1BQU0sYUFBYSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxBQUFDO1FBQzFELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQ2xDLFlBQVksRUFDWixhQUFhLEVBQ2I7WUFBQyxhQUFhO1NBQUMsRUFDZixRQUFRLENBQUMsT0FBTyxDQUNqQixBQUFDO1FBQ0YsTUFBTSxPQUFPLEdBQThCLE9BQU8sQ0FBQyxNQUFNLENBQ3RELFVBQVUsRUFBRSxDQUNaLFdBQVcsRUFBRSxBQUFDO1FBRWpCLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QyxPQUFPLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDN0MsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDM0IsT0FBTyxDQUFDLHdCQUF3QixDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDL0MsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDaEUsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUN6QztDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsOERBQThEO0lBQ3BFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQUMsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDcEQsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUssRUFBRSxFQUFFO1NBQUUsQUFBQztRQUN4RCxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ2QsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osZ0JBQWdCLEVBQ2hCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsTUFBTSxRQUFRLEdBQUc7WUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO1NBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLEdBQzlELEtBQUssQ0FBQyxjQUFjLENBQ2xCLFlBQVksRUFDWixhQUFhLEVBQ2I7Z0JBQUMsU0FBUzthQUFDLEVBQ1gsUUFBUSxDQUFDLE9BQU8sQ0FDakIsQ0FDRixBQUFDO1FBQ0YsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBSyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7S0FDeEQ7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLHVDQUF1QztJQUM3QyxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDdkUsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUssRUFBRSxFQUFFO1NBQUUsQUFBQztRQUN4RCxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osb0JBQW9CLEVBQ3BCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xELGlCQUFpQixDQUNmLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUMzQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUNQLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUMzQixLQUFLLENBQUMsT0FBTyxDQUNkLENBQUM7UUFDRixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FDN0MsS0FBSyxDQUFDLEtBQUssRUFDWCxLQUFLLENBQUMsT0FBTyxFQUNiLEtBQUssQ0FBQyxPQUFPLENBQ2QsQ0FBQztLQUNIO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSwwREFBMEQ7SUFDaEUsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQUMsVUFBVTtZQUFFLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FBQyxHQUFHLENBQ3ZFLENBQUMsSUFBSSxHQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEFBQUMsQ0FDOUIsQUFBQztRQUNGLE1BQU0sS0FBSyxHQUFHLEVBQUUsQUFBQztRQUNqQixNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sRUFBRSxvQkFBb0IsQ0FBQSxFQUFFLGNBQWMsQ0FBQSxFQUFFLEdBQUcsTUFBTSxDQUFDO1lBQ3RELEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7WUFDaEIsTUFBTSxFQUFFLEtBQUs7U0FDZCxDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUs7WUFBRSxvQkFBb0I7U0FBRSxBQUFDO1FBQzFFLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxnQkFBZ0IsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ3RELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1lBQzNDLEVBQUUsQ0FBQyxZQUFZLENBQ2IsWUFBWSxFQUNaLG1CQUFtQixFQUNuQjtnQkFDRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDYixLQUFLLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDO2dCQUNqQyxLQUFLLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDO2FBQ3RDLEVBQ0QsS0FBSyxDQUFDLE9BQU8sQ0FDZDtTQUNGLENBQUMsQUFBQztRQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNsRCxpQkFBaUIsQ0FDZixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDM0IsZ0JBQWdCLEVBQ2hCLE9BQU8sRUFDUCxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsRUFDM0IsS0FBSyxDQUFDLE9BQU8sQ0FDZCxDQUFDO1FBQ0YsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQ3ZELEtBQUssRUFDTCxLQUFLLENBQUMsT0FBTyxFQUNiLEtBQUssQ0FBQyxPQUFPLEVBQ2IsY0FBYyxDQUNmLENBQUM7S0FDSDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsMkJBQTJCO0lBQ2pDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQUMsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDcEQsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUssRUFBRSxFQUFFO1NBQUUsQUFBQztRQUN4RCxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osb0JBQW9CLEVBQ3BCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RELFlBQVksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDbEQ7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLGtDQUFrQztJQUN4QyxFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDdkUsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFBRSxLQUFLO1lBQUUsUUFBUTtZQUFFLFNBQVMsRUFBRSxLQUFLO1NBQUUsQ0FBQyxBQUFDO1FBQzVFLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixvQkFBb0IsRUFDcEI7Z0JBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUFDLEVBQ2xELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsa0NBQWtDO0lBQ3hDLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLE1BQU0sR0FBRyxFQUFFLEFBQUM7UUFDbEIsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNO1lBQUUsS0FBSyxFQUFFLEVBQUU7U0FBRSxBQUFDO1FBQ3BELEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDZCxnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ2xELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1NBQzVDLENBQUMsQ0FBQztRQUNILEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDdEMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixvQkFBb0IsRUFDcEI7Z0JBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUFDLEVBQ2xELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsaUVBQWlFO0lBQ3ZFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLE1BQU0sR0FBRyxFQUFFLEFBQUM7UUFDbEIsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUssRUFBRSxFQUFFO1NBQUUsQUFBQztRQUN4RCxNQUFNLHFCQUFxQixHQUFHLENBQUMsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxBQUFDO1FBQzlELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztZQUMzQyxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixvQkFBb0IsRUFDcEI7Z0JBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQzthQUFDLEVBQ3ZELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsaUVBQWlFO0lBQ3ZFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxFQUFFLEFBQUM7UUFDakIsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEVBQUUsb0JBQW9CLENBQUEsRUFBRSxHQUFHLE1BQU0sQ0FBQztZQUN0QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLE1BQU0sRUFBRSxLQUFLO1NBQ2QsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQVU7WUFBRSxPQUFPO1lBQUUsTUFBTSxFQUFFLEVBQUU7WUFBRSxLQUFLO1NBQUUsQUFBQztRQUNwRCxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsZ0JBQWdCLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUN0RCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztZQUMzQyxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixtQkFBbUIsRUFDbkI7Z0JBQ0UsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDakMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQzthQUN0QyxFQUNELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsZ0VBQWdFO0lBQ3RFLEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxFQUFFLEFBQUM7UUFDakIsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEVBQUUsb0JBQW9CLENBQUEsRUFBRSxHQUFHLE1BQU0sQ0FBQztZQUN0QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLE1BQU0sRUFBRSxLQUFLO1NBQ2QsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQVU7WUFBRSxPQUFPO1lBQUUsTUFBTSxFQUFFLEVBQUU7WUFBRSxLQUFLO1lBQUUsb0JBQW9CO1NBQUUsQUFBQztRQUMxRSxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsZ0JBQWdCLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUN0RCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztZQUMzQyxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixvQkFBb0IsRUFDcEI7Z0JBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUFDLEVBQ2xELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsaUhBQWlIO0lBQ3ZILEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxFQUFFLEFBQUM7UUFDakIsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEVBQUUsb0JBQW9CLENBQUEsRUFBRSxHQUFHLE1BQU0sQ0FBQztZQUN0QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLE1BQU0sRUFBRSxLQUFLO1NBQ2QsQ0FBQyxBQUFDO1FBQ0gsTUFBTSx5QkFBeUIsR0FBRyxDQUFDLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQUFBQztRQUNqRSxNQUFNLEtBQUssR0FBVTtZQUFFLE9BQU87WUFBRSxNQUFNLEVBQUUsRUFBRTtZQUFFLEtBQUs7WUFBRSxvQkFBb0I7U0FBRSxBQUFDO1FBQzFFLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDNUIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUNsRCxnQkFBZ0IsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ3RELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1lBQzNDLEVBQUUsQ0FBQyxZQUFZLENBQ2IsWUFBWSxFQUNaLG1CQUFtQixFQUNuQjtnQkFDRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDYixLQUFLLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDO2dCQUNqQyxLQUFLLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDO2FBQzNDLEVBQ0QsS0FBSyxDQUFDLE9BQU8sQ0FDZDtTQUNGLENBQUMsQUFBQztRQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0RCxZQUFZLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO0tBQ2xEO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSwrREFBK0Q7SUFDckUsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxHQUFHO1lBQUMsVUFBVTtZQUFFLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FBQyxHQUFHLENBQ3ZFLENBQUMsSUFBSSxHQUFLLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEFBQUMsQ0FDOUIsQUFBQztRQUNGLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQSxFQUFFLE9BQU8sQ0FBQSxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQzVDLEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxLQUFLLEdBQVU7WUFBRSxPQUFPO1lBQUUsTUFBTSxFQUFFLEVBQUU7WUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sR0FBRyxFQUFFO1NBQUUsQUFBQztRQUN4RSxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osb0JBQW9CLEVBQ3BCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ELFlBQVksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDbEQ7Q0FDRixDQUFDLENBQUM7QUFFSCxRQUFRLENBQUMsSUFBSSxDQUFDO0lBQ1osSUFBSSxFQUFFLGlGQUFpRjtJQUN2RixFQUFFLEVBQUMsS0FBWSxFQUFFLFFBQThCLEVBQUU7UUFDL0MsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtZQUFFLFVBQVU7U0FBQyxDQUFDLEdBQUcsQ0FDdkUsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUM5QixBQUFDO1FBQ0YsTUFBTSxLQUFLLEdBQUcsRUFBRSxBQUFDO1FBQ2pCLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQSxFQUFFLE9BQU8sQ0FBQSxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQzVDLEtBQUs7WUFDTCxRQUFRO1lBQ1IsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxFQUFFLG9CQUFvQixDQUFBLEVBQUUsR0FBRyxNQUFNLENBQUM7WUFDdEMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztZQUNoQixNQUFNLEVBQUUsS0FBSztTQUNkLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQ25CLE9BQU87WUFDUCxNQUFNLEVBQUUsRUFBRTtZQUNWLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxHQUFHLEVBQUU7WUFDekIsb0JBQW9CO1NBQ3JCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsZ0JBQWdCLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQztZQUN0RCxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQztZQUMzQyxFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixtQkFBbUIsRUFDbkI7Z0JBQ0UsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsS0FBSyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDakMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQzthQUN0QyxFQUNELEtBQUssQ0FBQyxPQUFPLENBQ2Q7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsMENBQTBDO0lBQ2hELEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsR0FBRztZQUFDLFVBQVU7WUFBRSxVQUFVO1lBQUUsVUFBVTtTQUFDLENBQUMsR0FBRyxDQUN2RSxDQUFDLElBQUksR0FBSyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxBQUFDLENBQzlCLEFBQUM7UUFDRixNQUFNLEVBQUUsZ0JBQWdCLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLE9BQU8sQ0FBQztZQUM1QyxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxLQUFLO1NBQ2pCLENBQUMsQUFBQztRQUNILE1BQU0sS0FBSyxHQUFVO1lBQ25CLE9BQU87WUFDUCxNQUFNLEVBQUUsRUFBRTtZQUNWLEtBQUssRUFBRSxFQUFFO1lBQ1QsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3JCLEFBQUM7UUFDRixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQzVCLGdCQUFnQixDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxRQUFRLENBQUM7WUFDbEQsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7WUFDM0MsRUFBRSxDQUFDLFlBQVksQ0FDYixZQUFZLEVBQ1osb0JBQW9CLEVBQ3BCO2dCQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUFFLEtBQUssQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7YUFBQyxFQUNsRCxLQUFLLENBQUMsT0FBTyxDQUNkO1NBQ0YsQ0FBQyxBQUFDO1FBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xELGlCQUFpQixDQUNmLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUMzQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUNQLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxFQUMzQixLQUFLLENBQUMsT0FBTyxDQUNkLENBQUM7UUFDRixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FDN0MsS0FBSyxDQUFDLEtBQUssRUFDWCxLQUFLLENBQUMsT0FBTyxFQUNiLEtBQUssQ0FBQyxPQUFPLENBQ2QsQ0FBQztLQUNIO0NBQ0YsQ0FBQyxDQUFDO0FBRUgsUUFBUSxDQUFDLElBQUksQ0FBQztJQUNaLElBQUksRUFBRSwrQ0FBK0M7SUFDckQsRUFBRSxFQUFDLEtBQVksRUFBRSxRQUE4QixFQUFFO1FBQy9DLE1BQU0sQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxlQUFlLENBQUMsR0FBRztZQUNoRCxVQUFVO1lBQ1YsVUFBVTtZQUNWLFVBQVU7WUFDVixVQUFVO1NBQ1gsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUFDLEFBQUM7UUFDckMsTUFBTSxFQUFFLGdCQUFnQixDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxPQUFPLENBQUM7WUFDNUMsS0FBSztZQUNMLFFBQVE7WUFDUixTQUFTLEVBQUUsS0FBSztTQUNqQixDQUFDLEFBQUM7UUFDSCxNQUFNLEtBQUssR0FBVTtZQUNuQixPQUFPO1lBQ1AsTUFBTSxFQUFFLEVBQUU7WUFDVixLQUFLLEVBQUUsRUFBRTtZQUNULEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztTQUNyQixBQUFDO1FBQ0YsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUM1QixnQkFBZ0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1lBQ2xELFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDO1lBQzNDLEVBQUUsQ0FBQyxZQUFZLENBQ2IsWUFBWSxFQUNaLG9CQUFvQixFQUNwQjtnQkFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDO2FBQUMsRUFDbEQsZUFBZSxDQUFDLE9BQU8sQ0FDeEI7U0FDRixDQUFDLEFBQUM7UUFDSCxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEQsWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztLQUNsRDtDQUNGLENBQUMsQ0FBQztBQUVILFFBQVEsQ0FBQyxJQUFJLENBQUM7SUFDWixJQUFJLEVBQUUsa0RBQWtEO0lBQ3hELEVBQUUsRUFBQyxLQUFZLEVBQUUsUUFBOEIsRUFBRTtRQUMvQyxNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxBQUFDLEFBQUM7UUFDM0MsTUFBTSxNQUFNLEdBQUcsR0FBRyxBQUFDO1FBRW5CLE1BQU0sWUFBWSxHQUFHLElBQU0sSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQUFBQztRQUUvQywrQ0FBK0M7UUFDL0MsTUFBTSxNQUFNLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtZQUFFLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FDNUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUNsQixHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUFDLEFBQUM7UUFDdEMsTUFBTSxNQUFNLEdBQUc7WUFBQyxVQUFVO1lBQUUsVUFBVTtZQUFFLFVBQVU7WUFBRSxVQUFVO1NBQUMsQ0FDNUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUNsQixHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQUFBQyxDQUFDLEFBQUM7UUFFdEMseURBQXlEO1FBQ3pELE1BQU0sS0FBSyxHQUFHO2VBQUksS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7U0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUN2RCxPQUFPLENBQUM7Z0JBQUUsS0FBSztnQkFBRSxRQUFRO2dCQUFFLFNBQVMsRUFBRSxRQUFRO2FBQUUsQ0FBQyxDQUNsRCxBQUFDO1FBRUYsa0RBQWtEO1FBQ2xELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLEdBQ2hDLE9BQU8sQ0FBQztnQkFBRSxLQUFLO2dCQUFFLFFBQVE7Z0JBQUUsU0FBUzthQUFFLENBQUMsQ0FDeEMsQUFBQztRQUNGLE1BQU0sTUFBTSxHQUFZLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFLLENBQUM7Z0JBQ2hELE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztnQkFDeEIsTUFBTTtnQkFDTixLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUM7YUFDbEMsQ0FBQyxDQUFDLEFBQUM7UUFFSiwyQkFBMkI7UUFDM0IsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUNkLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1NBQzVELENBQUMsQ0FBQztRQUVILGlCQUFpQjtRQUNqQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxDQUMzQixNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsR0FDbEIsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQ25FLENBQ0YsQUFBQztRQUNGLE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUM5QyxPQUFPLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUNyQyxBQUFDO1FBRUYsa0NBQWtDO1FBQ2xDLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQzVCLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUNsQixFQUFFLENBQUMsWUFBWSxDQUNiLFlBQVksRUFDWixvQkFBb0IsRUFDcEI7Z0JBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFBRSxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQzthQUFDLEVBQzVELEtBQUssQ0FBQyxPQUFPLENBQ2QsQ0FDRixDQUNGLEFBQUM7UUFFRixNQUFNLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQUFBQztRQUVwRCxzSEFBc0g7UUFDdEgsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFLO1lBQ2xDLFlBQVksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pELGlCQUFpQixDQUNmLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQ2pCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFDeEIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFDZixlQUFlLEVBQ2YsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FDbEIsQ0FBQztZQUNGLE9BQU8sQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQ25DLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQ2YsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFDakIsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FDbEIsQ0FBQztTQUNILENBQUMsQ0FBQztLQUNKO0NBQ0YsQ0FBQyxDQUFDIn0=